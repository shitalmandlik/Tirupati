<?php
class Upload extends CI_Controller
{
    public function index()
    {
      
      
        $errors=array();
        if(isset($_POST['submit_btn']) && isset($_FILES['insurance_file']) && isset($_FILES['rc_file']) && isset($_FILES['puc_file']))
         {
             $register_number=$_POST['reg_number'];
             $insurance_expiry=$_POST['insurance_exp'];
             $insurance_notify=$_POST['insurance_notify'];
             $rc_expiry=$_POST['rc_date'];
             $rc_notify=$_POST['rc_notify'];
             $puc_expiry=$_POST['puc_exp'];
             $puc_notify=$_POST['puc_notify'];
             
            $file_name=$_FILES['insurance_file']['name'];
            $file_tmp=$_FILES['insurance_file']['tmp_name'];
            $file_size=$_FILES['insurance_file']['size'];

            $ext=array("jpeg","jpg","png","pdf");
            $arr=explode(".",$file_name);
            $file_ext=strtolower(end($arr));
            if(in_array($file_ext, $ext)==false)
            {
                        
                $errors[]="Extensions not allowed,please choose image file or pdf";
                $this->session->set_flashdata('err_msg','Extensions not allowed,please choose image file or pdf');
                    redirect(base_url().'Adminity/fillDetails'); 
            }

            $file_name1=$_FILES['rc_file']['name'];
            $file_tmp1=$_FILES['rc_file']['tmp_name'];
            $file_size1=$_FILES['rc_file']['size'];

            $ext=array("jpeg","jpg","png","pdf");
            $arr=explode(".",$file_name1);
            $file_ext=strtolower(end($arr));
            if(in_array($file_ext, $ext)==false)
            {
                $errors[]="Extensions not allowed,please choose image file or pdf";
                        $this->session->set_flashdata('err_msg','Extensions not allowed,please choose image file or pdf');
                    redirect(base_url().'Adminity/fillDetails'); 
            }

            $file_name2=$_FILES['puc_file']['name'];
            $file_tmp2=$_FILES['puc_file']['tmp_name'];
            $file_size2=$_FILES['puc_file']['size'];

            $ext=array("jpeg","jpg","png","pdf");
            $arr=explode(".",$file_name2);
            $file_ext=strtolower(end($arr));
            if(in_array($file_ext, $ext)==false)
            {
                        $errors[]="Extensions not allowed,please choose image file or pdf";
                        $this->session->set_flashdata('err_msg','Extensions not allowed,please choose image file or pdf');
                    redirect(base_url().'Adminity/fillDetails'); 
            }

            else{
                mysql_connect("localhost","root","");
                mysql_select_db("tirupati23");
                move_uploaded_file($file_tmp, "uploads/insurance_files/".$file_name);
                move_uploaded_file($file_tmp1, "uploads/rc_files/".$file_name1);
                 move_uploaded_file($file_tmp2, "uploads/puc_files/".$file_name2);
              $sql="insert into document_tbl(insurance,rc,puc,register_number,insurance_expiry,insurance_notify,rc_expiry,rc_notify,puc_expiry,puc_notify) values('$file_name','$file_name1','$file_name2','$register_number','$insurance_expiry','$insurance_notify','$rc_expiry','$rc_notify','$puc_expiry','$puc_notify')";
                mysql_query($sql);
               
                
            }

        }

        if(empty($errors)==true)
        $this->session->set_flashdata('msg_ok','<i class="ti-check-box"></i> File uploaded Successfully.');
                    redirect(base_url().'Adminity/fillDetails'); 
       
    }
}
?>