<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supervisor extends CI_Controller {
	public function __construct()  
	{
            parent::__construct();	
            $this->load->model('tadmin_model');
            $this->load->model('admin');
            $this->load->library('session');
            date_default_timezone_set("Asia/Kolkata");
            $this->load->library('form_validation');
            $this->load->helper(array('form','url','file'));
            $this->deleteLastAssignedData();
	 
	}
	public function index()
	{
            if ($this->session->userdata('supervisor_login') == 1) {
                 $this->session->set_userdata('last_page', current_url());                  
                 $data['page_title'] = 'Dashboard';                  
                 $this->load->view('supervisor/index',$data);			
            }
            elseif($this->session->userdata('admin_login') == 1){
                 redirect(base_url().'Adminity');               
            }
            elseif($this->session->userdata('subadmin_login') == 1){
                 redirect(base_url().'Subadmin');               
            }
            elseif($this->session->userdata('vendor_login') == 1){
                 redirect(base_url().'Vendor');               
            }
            else{
                $data['page_title'] = 'Login';
                $this->load->view('myadmin/login',$data);
            }
	}        
	
         public function deleteLastAssignedData(){
             $this->db->order_by("fuel_mgt_id","desc");
             $onlyday = date('Y-m-d');
             $this->db->where("onlyday !=",$onlyday);
             $this->db->where("status",0);
             $this->db->where("otp_status",0);
            $fuel_mgt_info=$this->admin->record_list('fuel_mgt');
            foreach ($fuel_mgt_info as $fuel){                
                        $assign_id = $fuel->assign_id;
                        $fuel_mgt_id = $fuel->fuel_mgt_id;
                        
                        $data1=array('block'=>0,'fill_count'=>0);				        			
                        $where1 =array('assign_id'=>$assign_id);
                        $update=$this->admin->records_update('tbl_assign',$data1,$where1);
                        if($update){
                            $where =array('fuel_mgt_id'=>$fuel_mgt_id);
                            $this->admin->delete_record('fuel_mgt',$where);
                        }               
            }          
            
        }
        
        
         public function vendors($task='',$vendor_id='')
        {
            if ($this->session->userdata('supervisor_login') != 1) {
                        $this->session->set_userdata('last_page', current_url());
                        redirect(base_url());
                       }
                       
            if($task == 'addVendor'){
                         $this->form_validation->set_rules('vendor_name', 'Vendor Name', 'required');
			 $this->form_validation->set_rules('vendor_contact','Vendor Contact','required|is_unique[tbl_vendor.vendor_contact]');
			 $this->form_validation->set_rules('vendor_email', 'Vendor Email', 'required|valid_email');
			 $this->form_validation->set_rules('vendor_pass', 'Vendor Password', 'required');
			 $this->form_validation->set_rules('vendor_cpass', 'Vendor Confirm Password', 'required|matches[vendor_pass]');
			 $email=$this->input->post('vendor_email');
			 $password=$this->input->post('vendor_pass');
			
			 if ($this->form_validation->run())
			{
                            $data=array( 	  
	        			'vendor_name'=>ucwords(strtolower($this->input->post('vendor_name'))),
	        			'vendor_address'=>$this->input->post('vendor_address'),
	        			'vendor_contact'=>$this->input->post('vendor_contact'),
	        			'vendor_alternate_contact'=>$this->input->post('vendor_alternate_contact'),
	        			'password'=>strrev(sha1(md5($this->input->post('vendor_pass')))),
	        			'vendor_email'=>strtolower($this->input->post('vendor_email')),
	        			'GST_NO'=>$this->input->post('GST_NO'),
	        			'is_active'=>1
	        			);
					$details=$this->admin->record_insert('tbl_vendor',$data);
					$findemail = $this->admin->Sendmail($email,$password);

					$this->session->set_flashdata('msg_ok','<i class="ti-check-box"></i> Vendor Added Successfully.');
					redirect(base_url().'Supervisor/vendors');		
			}else {
                            $this->session->set_flashdata('err_msg',validation_errors());
                             redirect(base_url().'Supervisor/vendors');
                        }
           }
             if($task == 'editVendor'){
                         $this->form_validation->set_rules('vendor_name', 'Vendor Name', 'required');
			 $this->form_validation->set_rules('vendor_contact','Vendor Contact','required');
			 if ($this->form_validation->run())
			{
                             $data=array(
					'vendor_name'=>ucwords(strtolower($this->input->post('vendor_name'))),
	        			'vendor_address'=>$this->input->post('vendor_address'),
	        			'vendor_contact'=>$this->input->post('vendor_contact'),
	        			'vendor_alternate_contact'=>$this->input->post('vendor_alternate_contact'),
	        			'vendor_email'=>strtolower($this->input->post('vendor_email')),
	        			'GST_NO'=>$this->input->post('GST_NO'));
                                
                                        $where =array('vendor_id'=>$vendor_id);
					$vendors=$this->admin->records_update('tbl_vendor',$data,$where);
					$this->session->set_flashdata('msg_ok','<i class="ti-check-box"></i> Vendor Updated Successfully.');
					redirect(base_url().'Supervisor/vendors');		
			}else {
                            $this->session->set_flashdata('err_msg',validation_errors());
                             redirect(base_url().'Supervisor/vendors');
                        }                 
             }
             if($task == 'delete'){
                        $where =array('vendor_id'=>$vendor_id);
                        $this->admin->delete_record('tbl_vendor',$where);
                        $this->session->set_flashdata('msg_ok', ('<i class="ti-check-box"></i> Record Removed Successfully.'));
                        redirect(base_url() .'Supervisor/vendors');
             }
             
            $this->db->order_by("vendor_id","desc");
            $data['vendor_info']=$this->admin->record_list('tbl_vendor');
            $data['page_title']='Fuel Pumps';
            $this->load->view('supervisor/vendors',$data);
        }
        
        
        
           public function assignedDrivers($task = '',$assign_id = '',$is_active = '')
        {
            if ($this->session->userdata('supervisor_login') != 1) {
                        $this->session->set_userdata('last_page', current_url());
                        redirect(base_url());
                       }
                       
            if($task == 'assignDriverToVehicle'){
                $this->form_validation->set_rules('vehicle_id', 'Vehicle No', 'required');
		$this->form_validation->set_rules('driver_id', 'Driver Name', 'required');
			
		 if ($this->form_validation->run())
			{
                            $data=array( 	  
	        			'vehicle_id'=>$this->input->post('vehicle_id'),
	        			'driver_id'=>$this->input->post('driver_id'),
	        			'is_active'=>1);
				
					$details=$this->admin->record_insert('tbl_assign',$data);
					$this->session->set_flashdata('msg_ok','<i class="ti-check-box"></i> Driver Assigned to Vehicle Successfully.');
					redirect(base_url().'Supervisor/assignedDrivers');		
			}else {
                            $this->session->set_flashdata('err_msg',validation_errors());
                             redirect(base_url().'Supervisor/assignedDrivers');
                        }
            }
            if($task == 'delete'){
                        $where =array('assign_id'=>$assign_id);
                        $this->admin->delete_record('tbl_assign',$where);
                        $this->session->set_flashdata('msg_ok', ('<i class="ti-check-box"></i> Record Release Successfully.'));
                        redirect(base_url() .'Supervisor/assignedDrivers');
             }
             
             if($task == 'block'){
             		$data=array('is_active'=>$is_active);	        			
                        $where =array('assign_id'=>$assign_id);
                        $subadmin=$this->admin->records_update('tbl_assign',$data,$where);
                        //$this->admin->delete_record('tbl_assign',$where);
                        $this->session->set_flashdata('msg_ok', ('<i class="ti-check-box"></i> Vehicle Status Updated Successfully.'));
                        redirect(base_url() .'Supervisor/assignedDrivers');
             }
             if($task == 'reassign'){
             		$data=array('block'=>$is_active);	        			
                        $where =array('assign_id'=>$assign_id);
                        $subadmin=$this->admin->records_update('tbl_assign',$data,$where);
                        $this->session->set_flashdata('msg_ok', ('<i class="ti-check-box"></i> Vehicle Status Updated Successfully.'));
                        redirect(base_url() .'Supervisor/assignedDrivers');
             }
                
                
		$this->db->select('tbl_assign.*,tbl_vehicle.vehicle_no,tbl_driver.driver_name,tbl_driver.driver_contact');
		$this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id = tbl_assign.vehicle_id');
		$this->db->join('tbl_driver','tbl_driver.driver_id = tbl_assign.driver_id');
		$this->db->order_by('assign_id','desc');
            $data['assignedDrivers_info']=$this->admin->record_list('tbl_assign');
            $data['page_title']='Assigned Driver to Vehicle';
            $this->load->view('supervisor/assignedDrivertoVehicle',$data);
        }
        
        
           public function vehiclestoFuel($task='',$fuel_mgt_id='',$assign_id='')
        {
            if ($this->session->userdata('supervisor_login') != 1) {
                        $this->session->set_userdata('last_page', current_url());
                        redirect(base_url());
                       }
                if($task == 'delete'){
			$data1=array('block'=>0,'fill_count'=>0);				        			
                        $where1 =array('assign_id'=>$assign_id);
                        $subadmin=$this->admin->records_update('tbl_assign',$data1,$where1);
                        
                        $where =array('fuel_mgt_id'=>$fuel_mgt_id);
                        $this->admin->delete_record('fuel_mgt',$where);
                        $this->session->set_flashdata('msg_ok', ('<i class="ti-check-box"></i> Record Deleted Successfully.'));
                        redirect(base_url() .'Supervisor/vehiclestoFuel');
             }
                       
                $this->db->select('fuel_mgt.*,tbl_vendor.vendor_name,tbl_vendor.vendor_contact,tbl_supervisor.supervisor_name,tbl_supervisor.supervisor_contact,tbl_vehicle.vehicle_no,tbl_driver.driver_name,tbl_driver.driver_contact');
		 $this->db->join('tbl_vendor','tbl_vendor.vendor_id=fuel_mgt.vendor_id');
		 $this->db->join('tbl_supervisor','tbl_supervisor.supervisor_id=fuel_mgt.supervisor_id');		 
		 $this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id=fuel_mgt.vehicle_id');
		 $this->db->join('tbl_driver','tbl_driver.driver_id=fuel_mgt.driver_id');
		  //$this->db->join('otp','otp.fuel_mgt_id=fuel_mgt.fuel_mgt_id');
            $this->db->order_by("fuel_mgt_id","desc");
             $this->db->where('fuel_mgt.supervisor_id',$this->session->userdata('log_admin_id'));
             $this->db->where("status",0);
            $data['fuel_mgt_info']=$this->admin->record_list('fuel_mgt');
            $data['page_title']='Assigned Vehicles to Fuel';
            $this->load->view('supervisor/assignedVehiclestoFuel',$data);
        }
        
        
         public function fuelReceipts()
        {
            if ($this->session->userdata('supervisor_login') != 1) {
                        $this->session->set_userdata('last_page', current_url());
                        redirect(base_url());
                       }
                       
                $this->db->select('fuel_receipt.*,tbl_vendor.vendor_name,tbl_vendor.vendor_contact,tbl_supervisor.supervisor_name,tbl_supervisor.supervisor_contact,fuel_mgt.*,tbl_vehicle.vehicle_no,tbl_driver.driver_name,tbl_driver.driver_contact');
		$this->db->join('tbl_vendor','tbl_vendor.vendor_id=fuel_receipt.vendor_id');
		$this->db->join('tbl_supervisor','tbl_supervisor.supervisor_id=fuel_receipt.supervisor_id');
		$this->db->join('fuel_mgt','fuel_mgt.fuel_mgt_id=fuel_receipt.fuel_mgt_id');
		$this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id=fuel_mgt.vehicle_id');
		$this->db->join('tbl_driver','tbl_driver.driver_id=fuel_mgt.driver_id');
            $this->db->order_by("fuel_receipt_id","desc");
            $data['date'] = date('Y-m-d');
            $this->db->where('fuel_receipt.supervisor_id',$this->session->userdata('log_admin_id'));
            $this->db->where('fuel_receipt.receipt_date =', date('Y-m-d'));
            $data['fuel_Receipt_info']=$this->admin->record_list('fuel_receipt');
             $data['count']=count($data['fuel_Receipt_info']);
            $data['page_title']='Fuel Receipts';
            $this->load->view('supervisor/fuelReceipts',$data);
        }
        public function loadfuelReceipts()
        {
            if ($this->session->userdata('supervisor_login') != 1) {
                        $this->session->set_userdata('last_page', current_url());
                        redirect(base_url());
                       }
                       $fromdate  = $this->input->post('fromdate');
                        $todate = $this->input->post('todate');
                    
                $this->db->select('fuel_receipt.*,tbl_vendor.vendor_name,tbl_vendor.vendor_contact,tbl_supervisor.supervisor_name,tbl_supervisor.supervisor_contact,fuel_mgt.*,tbl_vehicle.vehicle_no,tbl_driver.driver_name,tbl_driver.driver_contact');
		$this->db->join('tbl_vendor','tbl_vendor.vendor_id=fuel_receipt.vendor_id');
		$this->db->join('tbl_supervisor','tbl_supervisor.supervisor_id=fuel_receipt.supervisor_id');
		$this->db->join('fuel_mgt','fuel_mgt.fuel_mgt_id=fuel_receipt.fuel_mgt_id');
		$this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id=fuel_mgt.vehicle_id');
		$this->db->join('tbl_driver','tbl_driver.driver_id=fuel_mgt.driver_id');
            $this->db->order_by("fuel_receipt_id","desc");
            $this->db->where('fuel_receipt.vendor_id',$this->input->post('vendor'));
            $this->db->where('fuel_receipt.receipt_date >=', $fromdate);
            $this->db->where('fuel_receipt.receipt_date <=', $todate);                           
            $data['fromdate'] = $fromdate;
	 	$data['todate'] = $todate;
	 	$data['vendor_id'] = $this->input->post('vendor');
            $this->db->where('fuel_receipt.supervisor_id',$this->session->userdata('log_admin_id'));          
            //$this->db->where('fuel_receipt.receipt_date <=', $todate); 
            //$data['date'] = $fromdate;
            $data['fuel_Receipt_info']=$this->admin->record_list('fuel_receipt');
            $data['count']=count($data['fuel_Receipt_info']);
            $data['page_title']='Fuel Receipts';
            $this->load->view('supervisor/fuelReceipts',$data);
        }
        
        
        public function fuelReceiptByDate($task='',$startdate='',$enddate='')
        {
            if ($this->session->userdata('supervisor_login') != 1) {
                        $this->session->set_userdata('last_page', current_url());
                        redirect(base_url());
                       }
                                              
                $this->db->select('fuel_receipt.*,tbl_vendor.vendor_name,tbl_vendor.vendor_contact,tbl_supervisor.supervisor_name,tbl_supervisor.supervisor_contact,fuel_mgt.*,tbl_vehicle.vehicle_no,tbl_driver.driver_name,tbl_driver.driver_contact');
		$this->db->join('tbl_vendor','tbl_vendor.vendor_id=fuel_receipt.vendor_id');
		$this->db->join('tbl_supervisor','tbl_supervisor.supervisor_id=fuel_receipt.supervisor_id');
		$this->db->join('fuel_mgt','fuel_mgt.fuel_mgt_id=fuel_receipt.fuel_mgt_id');
		$this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id=fuel_mgt.vehicle_id');
		$this->db->join('tbl_driver','tbl_driver.driver_id=fuel_mgt.driver_id');
            $this->db->order_by("fuel_receipt_id","desc");
            $this->db->where('fuel_receipt.supervisor_id',$this->session->userdata('log_admin_id'));
	    $data['page_title']='Fuel Receipts By Date';
            $data['fuel_Receipt_info']=$this->admin->record_list('fuel_receipt');            
            $this->load->view('supervisor/fuelReceiptsByDate',$data);
        }
        
        
        public function filterfuelReceiptByDate()
        {
            if ($this->session->userdata('supervisor_login') != 1) {
                        $this->session->set_userdata('last_page', current_url());
                        redirect(base_url());
                       }
                $this->form_validation->set_rules('fromdate','Start Date','required');
		$this->form_validation->set_rules('todate', 'From Date', 'required');
                if ($this->form_validation->run())
               {
                    $fromdate  = $this->input->post('fromdate');
                    $todate = $this->input->post('todate');
                    
                        $this->db->select('fuel_receipt.*,tbl_vendor.vendor_name,tbl_vendor.vendor_contact,tbl_supervisor.supervisor_name,tbl_supervisor.supervisor_contact,fuel_mgt.*,tbl_vehicle.vehicle_no,tbl_driver.driver_name,tbl_driver.driver_contact');
                        $this->db->join('tbl_vendor','tbl_vendor.vendor_id=fuel_receipt.vendor_id');
                        $this->db->join('tbl_supervisor','tbl_supervisor.supervisor_id=fuel_receipt.supervisor_id');
                        $this->db->join('fuel_mgt','fuel_mgt.fuel_mgt_id=fuel_receipt.fuel_mgt_id');
                        $this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id=fuel_mgt.vehicle_id');
                        $this->db->join('tbl_driver','tbl_driver.driver_id=fuel_mgt.driver_id');
                    if($this->input->post('vehicle_no')!="")
                       {
                       $this->db->where('fuel_mgt.vehicle_id',$this->input->post('vehicle_no'));
                     }
                     if($this->input->post('vendor')!="")
                       {
                       $this->db->where('fuel_receipt.vendor_id',$this->input->post('vendor'));
                     }
                       $this->db->where('fuel_receipt.receipt_date >=', $fromdate);
                       $this->db->where('fuel_receipt.receipt_date <=', $todate);        
                       $this->db->order_by("fuel_receipt_id","desc");
	 		$data['fromdate'] = $fromdate;
	         	$data['todate'] = $todate;
	         	$data['vendor_id'] = $this->input->post('vendor');
                     $data['page_title']='Fuel Receipts By Date';
                     $this->db->where('fuel_receipt.supervisor_id',$this->session->userdata('log_admin_id'));
                     $data['fuel_Receipt_info']=$this->admin->record_list('fuel_receipt');
                     $data['count']=count($data['fuel_Receipt_info']);           
                    $this->load->view('supervisor/filterfuelReceiptsByDate',$data);
                    
               }
               else
                {
                     $this->session->set_flashdata('err_msg',validation_errors());
                     redirect(base_url().'Supervisor/fuelReceiptByDate');
                }      
            
        }
        
        
         public function profile($task = '',$supervisor_id = '')
        {
            if ($this->session->userdata('supervisor_login') != 1) {
                        $this->session->set_userdata('last_page', current_url());
                        redirect(base_url());
                       }                       
            if($task == 'updateImage'){
                if($_FILES['userfile']['name']!= ""){
                      $img_name='userfile';
                      $img_path='supervisors';
                      $old_img=$this->input->post('old_admin_profile');
                      $profile=$this->admin->upload_image($img_name,$img_path,$old_img);  
                }
                        if($profile)
                        {
                            $data=array('profile_pic'=>$profile);                            
                                $where =array('supervisor_id'=>$supervisor_id);
                                $subadmin=$this->admin->records_update('tbl_supervisor',$data,$where);
                                $this->session->set_userdata('log_image', $profile);
                                $this->session->set_flashdata('msg_ok','<i class="ti-check-box"></i> Profile Image Updated Successfully.');
                                redirect(base_url().'Supervisor/profile');
                        }
                        else
                        {
                                    $this->session->set_flashdata('err_msg',$this->upload->display_errors());
                                    redirect(base_url() .'Supervisor/profile');

                        }
            }            
            if($task == 'updateAdminProfile'){
                        $this->form_validation->set_rules('admin_name', 'Admin Name', 'required');
			$this->form_validation->set_rules('admin_email','Admin Email ID','required|valid_email');
			$this->form_validation->set_rules('admin_mobile_no', 'Contact No', 'required|numeric');
                         if ($this->form_validation->run())
			{
                            $data=array(
					'supervisor_name'=>ucwords(strtolower($this->input->post('admin_name'))),
	        			'supervisor_email'=>strtolower($this->input->post('admin_email')),
	        			'supervisor_contact'=>$this->input->post('admin_mobile_no'),
	        			'supervisor_alternet_contact'=>$this->input->post('admin_alternatemobile'),
	        			'supervisor_address'=>$this->input->post('admin_address')
                                        );
                            
                                        $where =array('supervisor_id'=>$supervisor_id);
					$subadmin=$this->admin->records_update('tbl_supervisor',$data,$where);
					$this->session->set_flashdata('msg_ok','<i class="ti-check-box"></i> Profile Updated Successfully.');
					redirect(base_url().'Supervisor/profile');		
			}else {
                            $this->session->set_flashdata('err_msg',validation_errors());
                             redirect(base_url().'Supervisor/profile');
                        }
            }
            
            if($task =='updateAdminPassword'){                
                $this->form_validation->set_rules('old_password', 'Old Password', 'required');
                $this->form_validation->set_rules('password', 'Password', 'required');
                $this->form_validation->set_rules('confirm', 'Password Confirmation', 'required|matches[password]');

		if ($this->form_validation->run() == FALSE)
                {
                       $this->session->set_flashdata('err_msg', validation_errors());
                        redirect(base_url() . 'Supervisor/profile');
                }
                else
                {
                    $where =array('supervisor_id'=>$supervisor_id);
                    $table = 'tbl_supervisor';
                    $query = $this->tadmin_model->checkOldPassword($this->input->post('old_password'),$table,$where);

                            if($query)
                                    {
                                      $data=array('password'=> strrev(sha1(md5($this->input->post('password')))));
                                            $where =array('supervisor_id'=>$supervisor_id);
                                            $subadmin=$this->admin->records_update('tbl_supervisor',$data,$where);
                                            $this->session->sess_destroy();
                                            $this->session->set_flashdata('msg_ok', ('Password Updated Successfully'));
                                            redirect(base_url() . 'Supervisor/profile');
                                    }
                                    else
                                    {
                                         $this->session->set_flashdata('err_msg', 'Please Enter the correct password');
                                            redirect(base_url() . 'Supervisor/profile');
                                    }				 
		}
                
            }
            $supervisor_id = $this->session->userdata('log_admin_id');           
            $where =array('supervisor_id'=> $supervisor_id );
            $data['admin_info']=$this->admin->record_list('tbl_supervisor',$where);
            $data['page_title']='Profile Setting';
            $this->load->view('supervisor/myprofile',$data);
        }
        
        /******POPUP MODEL******/
        
        public function popup($account_type = '', $page_name = '', $param2 = '')
	{
                //$account_type               =	$this->session->userdata('login_type');
		$page_data['param2']		=	$param2;		
		//echo "hello";
		$this->load->view($account_type.'/'.$page_name,$page_data);		
	}
        
/*********APP API'S********/
 
               
         /*******ADD VEHICLE TO VENDOR FOR FUEL*****/
        
            public function assignVehicleToFuel(){
                if ($this->session->userdata('supervisor_login') != 1) {
                $this->session->set_userdata('last_page', current_url());
                redirect(base_url());
               } 
                    $this->form_validation->set_rules('vendor_id', 'Vendor ID', 'required');
                    $this->form_validation->set_rules('assign_id','assign_id','required');
                    $this->form_validation->set_rules('cost','cost','required|numeric');
                    
                if ($this->form_validation->run())
                {
                            $assign_id = $this->input->post('assign_id');
                            $assign_data = $this->db->get_where('tbl_assign',array('assign_id'=>$assign_id))->result_array();
                            foreach ($assign_data as $asign){
                                $vehicle_id = $asign['vehicle_id'];
                                $driver_id = $asign['driver_id'];
                            }
                            $vendor_id = $this->input->post('vendor_id');                            
                            $assigncost= $this->input->post('cost');                      			                                 
                                        
                            $dat=array( 	  
	        			'vendor_id' =>$vendor_id,
                                        'vehicle_id' =>$vehicle_id,
	        			'driver_id' =>$driver_id,
                                        'assign_id' =>$this->input->post('assign_id'),                                       
                                        'cost' => $assigncost,
                                        'date' =>date('Y-m-d h:m:s'),
                                        'onlyday' =>date('Y-m-d'),
	        			'supervisor_id' =>$this->session->userdata('log_admin_id')
	        			);
                            
                                    $insert=$this->db->insert('fuel_mgt',$dat);
                                    
                                    $date = date('Y-m-d');
                                    $d = array('fill_count' =>1,'block' =>2,'blockdate' =>$date);
                                    $this->db->where('assign_id',$this->input->post('assign_id'));
                                    $this->db->update('tbl_assign',$d);                                    
                                    
                                    $cost = $assigncost;
                                    $vehicle_data = $this->db->get_where('tbl_vehicle',array('vehicle_id' => $vehicle_id))->result_array();
                                    foreach($vehicle_data as $veh){
                                        $vehicle_no = $veh['vehicle_no'];
                                        $vehicle_owner_id = $veh['vehicle_owner_id'];
                                        $vehOwner = $this->db->get_where('vehicle_owner',array('vehicle_owner_id' => $vehicle_owner_id))->result_array();
                                        foreach($vehOwner as $vo){
                                            $name = $vo['owner_full_name'];
                                            $mob = $vo['contact_no'];
                                        }
                                    }                                   
                                    $driver_data = $this->db->get_where('tbl_driver',array('driver_id' => $driver_id))->result_array();
                                    foreach ($driver_data as $dr){
                                        $driver = $dr['driver_name'];
                                        $contact = '9922031316';//$dr['driver_contact'];
                                    }                                
                                    $msg ="Hello $name , Vehicle $vehicle_no is assigned to fuel with cost Rs $cost Driver $driver and Contact $contact";
                                    $sms = $this->send_message($mob,$msg);                                
                                
                        if($insert==1){
                             $this->session->set_flashdata('msg_ok','<i class="ti-check-box"></i> Vehicle Assigned Successfully.');
                             redirect(base_url().'Supervisor/vehiclestoFuel');
                        }else{
                            $this->session->set_flashdata('err_msg','Something Went Wrong..!');
                            redirect(base_url() . 'Supervisor/vehiclestoFuel');
                        }                    
                }else{
                        $this->session->set_flashdata('err_msg', validation_errors());
                        redirect(base_url() . 'Supervisor/vehiclestoFuel');
                }
                 
                       
        }
        
        /******ADD VEHICLE TO VENDOR FOR FUEL END*****/
        
        
        public function send_message($mob,$msg)
	{
               $web_url = "http://www.sms123.in/QuickSend.aspx?";
                $url = $web_url.http_build_query(array('username'=> "tirupati",'password' => "tirupati",
                    'mob' => $mob,'msg' => $msg,'sender' => "TRTRVL"));	
                
	 	// $url = $web_url.http_build_query(array('username'=> "tirupati",'password' => "tirupati",
                 //   'mob' => $mob,'msg' => $msg,'sender' => "TRTRVL"));	
	 	 //echo  $url;
                 //echo $shortUrl=file_get_contents($url);
		$ch = curl_init();
		if($ch)
		{					
			curl_setopt($ch, CURLOPT_URL, $url); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
			$result = curl_exec($ch );
		
			curl_close( $ch );
			return 1;
		}
		else
		{
			return 0;
		}
	}
        
        
        
        
        /******GET SUPERVISOR DATA*******/
        
        public function getSupervisor($id){
             $data = array();
            $this->db->where('supervisor_id',$id);
            $supervisor = $this->db->get('tbl_supervisor')->result_array();
             foreach ($supervisor as $sup){                 
              $sup_entry = array('supervisor_id' => $sup['supervisor_id'], 'name' => $sup['supervisor_name'], 'contact' => $sup['supervisor_contact'],'alternate_contact' => $sup['supervisor_alternet_contact'], 'email' => $sup['supervisor_email'],'address' => $sup['supervisor_address'],'profile_img' => $sup['profile_pic']);
              array_push($data, $sup_entry);
              }
                  
                    
            echo json_encode($data);
        }
        
        /******SET SUPERVISOR DATA*******/
        
        public function setSupervisorData($id){   
            $this->form_validation->set_rules('supervisor_name', 'Supervisor name', 'required');
             if ($this->form_validation->run() == FALSE)
                     {
                            $data['msg']= validation_errors();
                            $data['success'] = 0;
                     }
                    else
                     {
                        $img=$this->input->post('profile_img');
			$extension="jpg";
			$fileName = uniqid().'.'.$extension;
			$path='/home/techrnl/public_html/tirupati/assets/uploads/supervisors/'.$fileName;
                        
                            $data=array( 	  
                                        'supervisor_name' => strtoupper($this->input->post('supervisor_name')),
                                        'supervisor_alternet_contact' =>$this->input->post('alternate_contact'),
                                        'supervisor_name' =>$this->input->post('supervisor_name'),
                                        'profile_pic'=>$fileName,
	        			'supervisor_id' =>$this->input->post('supervisor_id')
	        			);                       

                        $result = file_put_contents($path, base64_decode($img)); 
                        
                               $this->db->where('supervisor_id',$id);
                               $insert= $this->db->update('tbl_supervisor',$data);
                        if($insert==1){
                            $data['msg']= 'Supervisor Data Updated Successfully..!';
                            $data['success'] = 1;
                        }else{
                            $data['msg']= 'Something Went Wrong..!';
                            $data['success'] = 0;
                        }
                    }  
                    echo json_encode($data);    
        }
        
         /******SET SUPERVISOR DATA END*******/
        
         /******GET ALL VENDOR DATA*******/
        
        public function getVendor(){
            $data = array();
            //$this->db->where('supervisor_id',$id);
            $vendor = $this->db->get('tbl_vendor')->result_array();
            foreach ($vendor as $sup){                 
              $ven_entry = array('vendor_id' => $sup['vendor_id'], 'name' => $sup['vendor_name'], 'contact' => $sup['vendor_contact'],'alternate_contact' => $sup['vendor_alternate_contact'], 'email' => $sup['vendor_email'],'address' => $sup['vendor_address'],'GSTIN' => $sup['GST_NO']);
               array_push($data, $ven_entry);
              }                
                  
            echo json_encode($data);
        }
        
         /******GET ALL VENDOR DATA END*******/
        
        /******GET SINGLE VENDOR DATA*******/
        
        public function getVendorProfile($id){
            $data = array();
            $this->db->where('vendor_id',$id);
            $vendor = $this->db->get('tbl_vendor')->result_array();
            foreach ($vendor as $sup){                 
              $ven_entry = array('vendor_id' => $sup['vendor_id'], 'name' => $sup['vendor_name'], 'contact' => $sup['vendor_contact'],'alternate_contact' => $sup['vendor_alternate_contact'], 'email' => $sup['vendor_email'],'address' => $sup['vendor_address'],'GSTIN' => $sup['GST_NO']);
               array_push($data, $ven_entry);
              }                
                  
            echo json_encode($data);
        }
        
         /******GET SINGLE VENDOR DATA END*******/
        
        /******SET VENDOR DATA*******/
        
        public function setVendorData($id){   
            $this->form_validation->set_rules('vendor_name', 'vendor name', 'required');
             if ($this->form_validation->run() == FALSE)
                     {
                            $data['msg']= validation_errors();
                            $data['success'] = 0;
                     }
                    else
                     {
                        $img=$this->input->post('profile_img');
			$extension="jpg";
			$fileName = uniqid().'.'.$extension;
			$path='/home/techrnl/public_html/tirupati/assets/uploads/vendors/'.$fileName;
                        
                            $data=array( 	  
                                        'vendor_name' => strtoupper($this->input->post('vendor_name')),
                                        'vendor_address' =>$this->input->post('vendor_address'),
                                        'vendor_alternate_contact' =>$this->input->post('alternate_contact'),
                                        'GST_NO' =>$this->input->post('gstin_no'),
                                        'profile_pic'=>$fileName
	        			);                       

                        $result = file_put_contents($path, base64_decode($img)); 
                        
                               $this->db->where('vendor_id',$id);
                               $insert= $this->db->update('tbl_vendor',$data);
                        if($insert==1){
                            $data['msg']= 'Vendor Data Updated Successfully..!';
                            $data['success'] = 1;
                        }else{
                            $data['msg']= 'Something Went Wrong..!';
                            $data['success'] = 0;
                        }
                    }  
                    echo json_encode($data);    
        }
        
         /******SET VENDOR DATA END*******/
        
         /******GET SUPERVISORWISE NOT ASSIGNED DRIVER DATA*******/
        
        public function getDriverForAssign($id){
            $data = array();
            $this->db->where('supervisor_id',$id);
            $driver = $this->db->get('tbl_driver')->result_array();
            foreach ($driver as $sup){ 
                 $drive = $this->db->get_where('tbl_assign',array('driver_id' =>$sup['driver_id']))->result_array();
                 if($drive){
                     
                 }
                 else{
                $driver_entry = array('driver_id' => $sup['driver_id'], 'name' => strtoupper($sup['driver_name']), 'contact' => $sup['driver_contact'],'alternate_contact' => $sup['alternat_contact'], 'address' => $sup['driver_address'],'licence_no' => strtoupper($sup['license']));
                array_push($data, $driver_entry);
                 }
              }
            echo json_encode($data);
        }
        /******GET SUPERVISORWISE NOT ASSIGNED DRIVER DATA END*******/
        
        /******GET SUPERVISORWISE ALL DRIVER DATA*******/
        
        public function getDriver($id){
            $data = array();
            $this->db->where('supervisor_id',$id);
            $driver = $this->db->get('tbl_driver')->result_array();
            foreach ($driver as $sup){                 
              $driver_entry = array('driver_id' => $sup['driver_id'], 'name' => strtoupper($sup['driver_name']), 'contact' => $sup['driver_contact'],'alternate_contact' => $sup['alternat_contact'], 'address' => $sup['driver_address'],'licence_no' => strtoupper($sup['license']));
               array_push($data, $driver_entry);
              }
            echo json_encode($data);
        }
        /******GET SUPERVISORWISE ALL DRIVER DATA END*******/
        
        
        /******GET SUPERVISORWISE NOT ASSIGNED VEHICLE DATA*******/
        
        public function getVehicleForAssign($id){
            $data = array();
            $this->db->where('supervisor_id',$id);
            $vehicle = $this->db->get('tbl_vehicle')->result_array();
             foreach ($vehicle as $veh){
                  $vehi = $this->db->get_where('tbl_assign',array('vehicle_id' =>$veh['vehicle_id']))->result_array();
                 if($vehi){
                     
                 }else{
                    $veh_entry = array('vehicle_id' => $veh['vehicle_id'], 'vehicle_no' => strtoupper($veh['vehicle_no']));                  
                    array_push($data, $veh_entry);
                 }
            }            
            echo json_encode($data);
        }
        /******GET SUPERVISORWISE NOT ASSIGNED VEHICLE DATA END*******/
        
        
        /******GET SUPERVISORWISE NOT ASSIGNED VEHICLE TO FUEL DATA*******/
        
        public function getVehicleForFuel($id){
            $data = array();
            $this->db->where('supervisor_id',$id);
            $vehicle = $this->db->get('tbl_vehicle')->result_array();
             foreach ($vehicle as $veh){
                  $vehi = $this->db->get_where('fuel_mgt',array('vehicle_id' =>$veh['vehicle_id'],'status' => 0))->result_array();
                 if($vehi){                     
                 }else{                  
                    $veh_entry = array('vehicle_id' => $veh['vehicle_id'], 'vehicle_no' => strtoupper($veh['vehicle_no']));                  
                    array_push($data, $veh_entry);
                 }
            }            
            echo json_encode($data);
        }
        /******GET SUPERVISORWISE NOT ASSIGNED VEHICLE TO FUEL DATA END*******/
        
        /******GET SUPERVISORWISE VEHICLE DATA*******/
        
        public function getVehicle($id){
            $data = array();
             $this->db->where('supervisor_id',$id);
            $vehicle = $this->db->get('tbl_vehicle')->result_array();            
            foreach ($vehicle as $veh){
                  $owner =  $this->db->get_where('vehicle_owner',array('vehicle_owner_id' => $veh['vehicle_owner_id']))->result_array();
                   foreach ($owner as $own){
                   }
                    $veh_entry = array('vehicle_id' => $veh['vehicle_id'], 'vehicle_no' => strtoupper($veh['vehicle_no']), 'vehicle_owner_id' => $veh['vehicle_owner_id'],'owner_name' => strtoupper($own['owner_full_name']), 'contact_no' => $own['contact_no']);                  
                    array_push($data, $veh_entry);
            }
            echo json_encode($data);
        }
         /******GET SUPERVISORWISE VEHICLE DATA END*******/
        
         /******GET SUPERVISORWISE VEHICLE-OWNER DATA*******/
        
        public function getVehicleOwner($id){
            $data = array();
             $this->db->where('supervisor_id',$id);
            $owner = $this->db->get('vehicle_owner')->result_array();
            foreach ($owner as $own){                       
                       $owner_entry = array('vehicle_owner_id' => $own['vehicle_owner_id'], 'name' => strtoupper($own['owner_full_name']), 'address' => $own['owner_address'],'email' => $own['Email_id'], 'contact' => $own['contact_no'],'alternate_no' => $own['Alternat_no']);                  
                   
                        array_push($data, $owner_entry);
                    }
                   
            echo json_encode($data);
        }
         /******GET SUPERVISORWISE VEHICLE-OWNER DATA END*******/
        
         /******GET SUPERVISORWISE ASSIGNED VEHICLE-DRIVER DATA*******/
        
         public function getAssignVehicleDriver($id){
              $data = array();
             $this->db->where('supervisor_id',$id);
            $assign = $this->db->get('tbl_assign')->result_array();
            foreach($assign as $row){                
                $vehicle =  $this->db->get_where('tbl_vehicle',array('vehicle_id' => $row['vehicle_id']))->result_array();
                   foreach ($vehicle as $veh){                       
                       //$veh_entry = array('assign_id' => $row['assign_id'],'vehicle_id' => $row['vehicle_id'], 'vehicle_no' => $veh['vehicle_no'], 'driver_id' => $row['driver_id']);
                  }
                  
                   $driver =  $this->db->get_where('tbl_driver',array('driver_id' => $row['driver_id']))->result_array();
                   foreach ($driver as $drv){  
                       $veh_entry = array('assign_id' => $row['assign_id'],'vehicle_id' => $row['vehicle_id'], 'vehicle_no' => $veh['vehicle_no'], 'driver_id' => $row['driver_id'],'driver_name' => $drv['driver_name'],'driver_contact' => $drv['driver_contact']);
                  }                  
                   array_push($data, $veh_entry);
            }
            echo json_encode($data);
        }
         /******GET SUPERVISORWISE ASSIGNED VEHICLE-DRIVER DATA END*******/
        
        /******DELETE SUPERVISORISE ASSIGNED VEHICLE-DRIVER DATA*******/
        
         public function deleteAssignVehicleDriver($id){
             $this->db->where('assign_id',$id);
             $details=$this->db->delete('tbl_assign');
             if($details){
             $data['msg'] = 'Data Deleted Successfully..!';
             $data['success'] = 1;
            }else{
                $data['msg'] = 'Something went wrong..!';
                $data['success'] = 0;
            }
            echo json_encode($data);
        }
         /******DELETE SUPERVISORWISE ASSIGNED VEHICLE-DRIVER DATA END*******/
        
        /******GET SUPERVISORWISE ASSIGNED VEHICLE-TO FUEL DATA*******/
        
         public function getAssignVehicleTofuel($id){
              $data = array();
              $this->db->where('status',0);
             $this->db->where('supervisor_id',$id);
            $fuel = $this->db->get('fuel_mgt')->result_array();
            foreach($fuel as $row){                
                $vehicle =  $this->db->get_where('tbl_vehicle',array('vehicle_id' => $row['vehicle_id']))->result_array();
                   foreach ($vehicle as $veh){                       
                       //$veh_entry = array('assign_id' => $row['assign_id'],'vehicle_id' => $row['vehicle_id'], 'vehicle_no' => $veh['vehicle_no'], 'driver_id' => $row['driver_id']);
                  }
                  $vendor =  $this->db->get_where('tbl_vendor',array('vendor_id' => $row['vendor_id']))->result_array();
                   foreach ($vendor as $ven){                       
                       //$veh_entry = array('assign_id' => $row['assign_id'],'vehicle_id' => $row['vehicle_id'], 'vehicle_no' => $veh['vehicle_no'], 'driver_id' => $row['driver_id']);
                  }                  
                   $driver =  $this->db->get_where('tbl_driver',array('driver_id' => $row['driver_id']))->result_array();
                   foreach ($driver as $drv){  
                       $veh_entry = array('fuel_mgt_id' => $row['fuel_mgt_id'],'vendor_id' => $row['vendor_id'],'vendor_name' => $ven['vendor_name'],'vendor_contact' => $ven['vendor_contact'],'vehicle_id' => $row['vehicle_id'], 'vehicle_no' => $veh['vehicle_no'], 'driver_id' => $row['driver_id'],'driver_name' => $drv['driver_name'],'driver_contact' => $drv['driver_contact'],'cost' => $row['cost'],'date' =>$row['date'],'supervisor_id' => $row['supervisor_id']);
                  }                  
                   array_push($data, $veh_entry);
            }
            echo json_encode($data);
        }
         /******GET SUPERVISORWISE ASSIGNED VEHICLE-TO FUEL DATA END*******/
        
        /******UPLOAD FUEL RECEIPT DATA*******/
        
         public function uploadFuelReceipt(){
            $this->form_validation->set_rules('vendor_id', 'Vendor ID', 'required');
            $this->form_validation->set_rules('fuel_mgt_id', 'Fuel Mgt ID', 'required');;
            $this->form_validation->set_rules('date','date','required');
            $this->form_validation->set_rules('supervisor_id','Supervisor','required');
             if ($this->form_validation->run() == FALSE)
                     {
                            $data['msg']= 'All Fields Required..!';
                            $data['success'] = 0;
                     }
                    else
                     {
                        $img=$this->input->post('receipt');
			$extension="jpg";
			$fileName = uniqid().'.'.$extension;
			$path='/home/techrnl/public_html/tirupati/assets/uploads/receipts/'.$fileName;
                        
                            $dat=array( 	  
	        			'vendor_id' =>$this->input->post('vendor_id'),
                                        'fuel_mgt_id' =>$this->input->post('fuel_mgt_id'),
                                        'receipt_path'=>$fileName,
                                        'date' =>$this->input->post('date'),
	        			'supervisor_id' =>$this->input->post('supervisor_id')
	        			);                       

                        $result = file_put_contents($path, base64_decode($img)); 
                        
			$insert=$this->db->insert('fuel_receipt',$dat);
                                $data['status'] = 1;
                                $this->db->where('fuel_mgt_id',$this->input->post('fuel_mgt_id'));
                                $this->db->update('fuel_mgt',$data);
                        if($insert==1){
                            $data['msg']= 'Receipt Uploaded Successfully..!';
                            $data['success'] = 1;
                        }else{
                            $data['msg']= 'Something Went Wrong..!';
                            $data['success'] = 0;
                        }
                    }  
                    echo json_encode($data);            
        
        }
         /******UPLOAD FUEL RECEIPT DATA END*******/
        
         /******GET SUPERVISORISE ASSIGNED VEHICLE-TO FUEL DATA*******/
        
         public function getfuelReceipts($id){
              $data = array();
              //$this->db->where('status',0);
             $this->db->where('supervisor_id',$id);
            $fuel = $this->db->get('fuel_receipt')->result_array();
            foreach($fuel as $row){                
                
                  $vendor =  $this->db->get_where('tbl_vendor',array('vendor_id' => $row['vendor_id']))->result_array();
                   foreach ($vendor as $ven){                       
                       
                  }                  
                  $fuel_mgt =  $this->db->get_where('fuel_mgt',array('fuel_mgt_id' => $row['fuel_mgt_id']))->result_array();
                   foreach ($fuel_mgt as $fuel){                       
                      $vehicle =  $this->db->get_where('tbl_vehicle',array('vehicle_id' => $fuel['vehicle_id']))->result_array();
                         foreach ($vehicle as $veh){                       
                            
                        }
                         $driver =  $this->db->get_where('tbl_driver',array('driver_id' => $fuel['driver_id']))->result_array();
                         foreach ($driver as $drv){  
                             $veh_entry = array('fuel_receipt_id' => $row['fuel_receipt_id'],'vendor_id' => $row['vendor_id'],'vendor_name' => $ven['vendor_name'],'vendor_contact' => $ven['vendor_contact'],'vehicle_id' => $veh['vehicle_id'], 'vehicle_no' => $veh['vehicle_no'], 'driver_id' => $drv['driver_id'],'driver_name' => $drv['driver_name'],'driver_contact' => $drv['driver_contact'],'cost' =>$fuel['cost'],'date' =>$row['date'],'receipt' => $row['receipt_path']);
                        }  
                  }
                   array_push($data, $veh_entry);
            }
            echo json_encode($data);
        }
        
         /******GET SUPERVISORISE ASSIGNED VEHICLE-TO FUEL DATA END*******/
        
        /******GET VENDORWISE ASSIGNED VEHICLE-TO FUEL DATA*******/
        
         public function getVendorfuelReceipts($id){
              $data = array();
              //$this->db->where('status',0);
             $this->db->where('vendor_id',$id);
            $fuel = $this->db->get('fuel_receipt')->result_array();
            foreach($fuel as $row){           
                
                  $fuel_mgt =  $this->db->get_where('fuel_mgt',array('fuel_mgt_id' => $row['fuel_mgt_id']))->result_array();
                   foreach ($fuel_mgt as $fuel){                       
                      $vehicle =  $this->db->get_where('tbl_vehicle',array('vehicle_id' => $fuel['vehicle_id']))->result_array();
                         foreach ($vehicle as $veh){                       
                            
                        }
                        $supervisor =  $this->db->get_where('tbl_supervisor',array('supervisor_id' => $fuel['supervisor_id']))->result_array();
                         foreach ($supervisor as $sup){                       
                            
                        }
                         $driver =  $this->db->get_where('tbl_driver',array('driver_id' => $fuel['driver_id']))->result_array();
                         foreach ($driver as $drv){  
                             $veh_entry = array('fuel_receipt_id' => $row['fuel_receipt_id'],'vehicle_id' => $veh['vehicle_id'], 'vehicle_no' => strtoupper($veh['vehicle_no']), 'driver_id' => $drv['driver_id'],'driver_name' => strtoupper($drv['driver_name']),'driver_contact' => $drv['driver_contact'],'supervisor_id' => $fuel['supervisor_id'],'supervisor_name' => $sup['supervisor_name'],'supervisor_contact' => $sup['supervisor_contact'],'cost' =>$fuel['cost'],'date' =>$row['date'],'receipt' => $row['receipt_path']);
                        }  
                  }
                   array_push($data, $veh_entry);
            }
            echo json_encode($data);
        }
        
         /******GET VENDORWISE ASSIGNED VEHICLE-TO FUEL DATA END*******/
        
/*******APP API'S END************/        

public function fule_Receipt()
	{
		$where=array(
						'fuel_receipt.supervisor_id'=>$this->session->userdata('supervisor_id')
			);
		$this->db->select('fuel_receipt.*,tbl_vendor.vendor_name,tbl_vendor.vendor_contact,tbl_supervisor.supervisor_name,tbl_supervisor.supervisor_contact,fuel_mgt.*,tbl_vehicle.vehicle_no,tbl_driver.driver_name,tbl_driver.driver_contact');
		$this->db->join('tbl_vendor','tbl_vendor.vendor_id=fuel_receipt.vendor_id');
		$this->db->join('tbl_supervisor','tbl_supervisor.supervisor_id=fuel_receipt.supervisor_id');
		$this->db->join('fuel_mgt','fuel_mgt.fuel_mgt_id=fuel_receipt.fuel_mgt_id');
		$this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id=fuel_mgt.vehicle_id');
		$this->db->join('tbl_driver','tbl_driver.driver_id=fuel_mgt.driver_id');
		$this->data['fule_Receipt']=$this->admin->record_list('fuel_receipt',$where);
		$this->data['page_title']='Fuel Receipt';
		$this->load->view('Supervisor/header',$this->data);
		$this->load->view('Supervisor/fuel_receipt',$this->data);
	}
public function assign_fuel()
	{
		if(isset($_POST['assign_fuel']))
		{
			$this->form_validation->set_rules('assign_id', 'Vehicle No', 'required');
			$this->form_validation->set_rules('vendor_id', 'Driver Name', 'required');
			
			
			 if ($this->form_validation->run())
			{
				$wheredriver=array(
								'assign_id'=>$this->input->post('assign_id')
								);
				$details=$this->admin->record_list('tbl_assign',$wheredriver);
			 	  		$data['supervisor_id']=$this->session->userdata('supervisor_id');
	        			$data['assign_id']=$this->input->post('assign_id');
	        			$data['vendor_id']=$this->input->post('vendor_id');
	        			$data['vehicle_id']=$details[0]->vehicle_id;
	        			$data['driver_id']=$details[0]->driver_id;
	        			$data['cost']=$this->input->post('cost');
	        			$data['date']=$this->input->post('date');
				
	        			
					$fuel_ass=$this->admin->record_insert('fuel_mgt',$data);
					
					$this->session->set_flashdata('message_success','Assign Entry Successfully Added.');
					redirect(base_url().'Supervisor/assign_fuel');		
				}
			}



		$where=array(
						'fuel_mgt.supervisor_id'=>$this->session->userdata('supervisor_id')
			);
		 $this->db->select('fuel_mgt.*,tbl_vendor.vendor_name,tbl_vendor.vendor_contact,tbl_supervisor.supervisor_name,tbl_supervisor.supervisor_contact,tbl_vehicle.vehicle_no,tbl_driver.driver_name,tbl_driver.driver_contact');
		 $this->db->join('tbl_vendor','tbl_vendor.vendor_id=fuel_mgt.vendor_id');
		 $this->db->join('tbl_supervisor','tbl_supervisor.supervisor_id=fuel_mgt.supervisor_id');
		 
		 $this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id=fuel_mgt.vehicle_id');
		 $this->db->join('tbl_driver','tbl_driver.driver_id=fuel_mgt.driver_id');
		$this->data['fuel_mgt']=$this->admin->record_list('fuel_mgt',$where);
		$this->db->select('tbl_assign.*,tbl_vehicle.vehicle_id,tbl_vehicle.vehicle_no,tbl_driver.driver_id,tbl_driver.driver_name');
		$this->db->join('tbl_vehicle','tbl_vehicle.vehicle_id=tbl_assign.vehicle_id');
		$this->db->join('tbl_driver','tbl_driver.driver_id=tbl_assign.driver_id');
		$this->data['assign']=$this->admin->record_list('tbl_assign');
		$this->data['vendor']=$this->admin->record_list('tbl_vendor');
		$this->data['page_title']='Assign Fuel';
		$this->load->view('Supervisor/header',$this->data);
		$this->load->view('Supervisor/assign_fuel',$this->data);
	}
        

	

public function Supervisor()
	{
		/******  Add Driver *******/
		if(isset($_POST['add_supervisor']))
		{
			$this->form_validation->set_rules('supervisor_name', 'Vendor Name', 'required');
			 
			
			 if ($this->form_validation->run())
			{
			
			$data=array( 	  
	        			'supervisor_name'=>$this->input->post('supervisor_name'),
	        			'supervisor_contact'=>$this->input->post('supervisor_contact'),
	        			'supervisor_alternet_contact'=>$this->input->post('supervisor_alternet_contact'),
	        			'supervisor_email'=>$this->input->post('supervisor_email'),
	        			'supervisor_address'=>$this->input->post('supervisor_address'),
	        			'pass'=>md5($this->input->post('pass')),
	        			'is_active'=>1
	        			);
					//echo"<pre>";print_r($data);die;

					$details=$this->admin->record_insert('tbl_supervisor',$data);
					$this->session->set_flashdata('message_success','Supervisor Successfully Added.');
					redirect(base_url().'Supervisor/Supervisor');		
				}
			}
		/****** End Add Driver ******/
		/****** Edit Driver *****/
			if(isset($_POST['update_supervisor']))
		{
			$this->form_validation->set_rules('supervisor_name', 'Vendor Name', 'required');
			 if ($this->form_validation->run())
			{
				
				$where =array( 	  
						'supervisor_id'=>$this->input->post('supervisor_id'),
	    			);	
				
					$data=array(
						'supervisor_name'=>$this->input->post('supervisor_name'),
	        			'supervisor_contact'=>$this->input->post('supervisor_contact'),
	        			'supervisor_alternet_contact'=>$this->input->post('supervisor_alternet_contact'),
	        			'supervisor_email'=>$this->input->post('supervisor_email'),
	        			'supervisor_address'=>$this->input->post('supervisor_address')
						);

					$vendors=$this->admin->records_update('tbl_supervisor',$data,$where);
					$this->session->set_flashdata('message_success','Supervisor Successfully update.');
					redirect(base_url().'Supervisor/Supervisor');		
				}
			}

			/****** End Edit Driver *****/
		$this->data['supervisor']=$this->admin->record_list('tbl_supervisor');
		$this->load->view('Supervisor/header');
		$this->load->view('Supervisor/supervisors',$this->data);
	}

	/***Delete Driver***/
	public function deleteSupervisor()
	{	
			$where=array(
				'supervisor_id'=>$this->uri->segment(3)
			);
		
		$vendor=$this->admin->record_list('tbl_supervisor',$where);

		if(!$vendor)
		{
		 	$this->session->set_flashdata('message_failed','Supervisor not Found...');
        	redirect(base_url().'Supervisor/Supervisor');
		}
		 

        $delete_id=$this->admin->records_delete('tbl_supervisor',$where);        
       
        if($delete_id){
        	$this->session->set_flashdata('message_success','Supervisor Deleted Successfully...');
        	redirect(base_url().'Supervisor/Supervisor');
    	}  
	}
	/*** ENd Delete Vendor***/

	

	


	



	public function logout()
	{
		$this->session->sess_destroy();	
		redirect(base_url());
	}

}
