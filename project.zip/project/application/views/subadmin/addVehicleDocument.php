<?php  $sites=$this->db->get('sites')->result(); 
        $document_list = $this->db->get('document_list')->result_array();
?>
<!-- Styles -->
  <section id="main-content">
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Add Document</h4>
                                    </div>
                                </div>
                                <form action="<?php echo base_url();?>Subadmin/vehicles/addVehicleDocument" method="post">
                                <div class="row">
                                    <input type="text"  name="expiry_date" required="" maxlength="13" pattern="" class="form-control border-none input-flat  bg-ash" placeholder="Expiry date">

                                    <div class="col-md-6">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Expiry Date <span class="required">*</span></label>
                                                    <input type="text"  name="expiry_date" required="" maxlength="13" pattern="" class="form-control border-none input-flat  bg-ash" placeholder="Expiry date">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                <label>Upload Document <span class="required">*</span></label>
                                                <input type="file"  name="document_file"  class="form-control border-none input-flat  bg-ash">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                <label>Select Document Type <span class="required">*</span></label>
                                                <select class="form-control etype" required="" name="vehicle_owner_id" id="vehicle_owner_id">
                                                    <option disabled value=""> ---Select Document Type--- </option>
                                                    <?php
                                                    foreach($document_list as $row)
                                                    {?>
                                                     <option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
                                                    <?php }
                                                    ?>
                                                </select> 
                                               
                                            </div>
                                        </div>
                                    </div>  

                                                                       
                                    <div class="col-md-12">
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-save"></i> Add Vehicle</button>
                                            <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                        </div>  
                                   </div>
                                </div>                                
                                </form>
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
   </section>

    <!-- scripit init-->

<!--
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/moment.latest.min.js"></script>
     scripit init
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/semantic.ui.min.js"></script>
     scripit init
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/prism.min.js"></script>
     scripit init
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/pignose.calendar.min.js"></script>
     scripit init
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/pignose.init.js"></script>
     scripit init-->
