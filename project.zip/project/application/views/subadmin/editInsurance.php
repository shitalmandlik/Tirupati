<?php $insurance_info = $this->db->get_where('insurance_tbl', array('insurance_id' => $param2))->result_array();
 foreach ($insurance_info as $row) {
?><!-- Styles -->
    <link href="<?php echo base_url();?>mypanel/assets/css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
       <section id="main-content">
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Update Insurance Details</h4>                                        
                                    </div>
                                </div>
                                <form action="<?php echo base_url();?>/Adminity/insurance/editInsurance/<?php echo $row['insurance_id'];?>" method="post">   
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Insurance Number <span class="required">*</span></label>
                                                    <input type="text" value="<?php echo $row['insurance_no'];?>" name="insurance_no" required="" class="form-control border-none input-flat  bg-ash" placeholder="Insurance Number">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Expiry Date<span class="required">*</span></label>
                                                    <input type="date" value="<?php echo $row['expiry_date'];?>" name="expiry_date" required=""   class="form-control border-none input-flat  bg-ash" >
                                            </div>
                                        </div>
                                    </div>
                                               
                                                                       
                                    <div class="col-md-12">
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-pencil-alt"></i> Update Insurance</button>
                                            <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                        </div>  
                                   </div>
                                </div>                                
                                </form>
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
   </section>
 <?php }?>
    <!-- scripit init-->
