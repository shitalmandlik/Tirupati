<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>
                     <li class="label">Dashboard</li>
                     <?php if($page_title=='Dashboard'){?>
                    <li class="active">
                    <?php } else { ?><li> <?php }?>
                        <a href="<?php echo base_url();?>" class="">
                            <i class="ti-home"></i> Dashboard </a>
                       
                    </li>
                     <?php if($page_title=='System OTP' || $page_title=='Vehicle Owner' || $page_title=='Vehicles' || $page_title=='Drivers' || $page_title=='Fuel Pumps' || $page_title=='Sites' || $page_title=='Supervisors' || $page_title=='Subadmin'){?>
                            <li class="active open">
                            <?php } else { ?><li> <?php }?>
                        <a class="sidebar-sub-toggle"><i class="ti-plus"></i>Basic Entries<span class="badge badge-primary">5</span><span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>
                             <?php if($page_title=='Vehicle Owner'){?>
                            <li class="active">
                            <?php } else { ?><li> <?php }?>
                                <a href="<?php echo base_url();?>Subadmin/vehicleOwners"><i class="ti-user"></i>Vehicle Owners</a>
                            </li>
                            <?php if($page_title=='Vehicles'){?>
                            <li class="active">
                            <?php } else { ?><li> <?php }?>
                                <a href="<?php echo base_url();?>Subadmin/vehicles"><i class="ti-truck"></i>Vehicles</a>
                            </li>

                            <?php if($page_title=='Vehicles'){?>
                                <li class="active">
                            <?php } else { ?><li> <?php }?>
                                <a href="<?php echo base_url();?>Subadmin/documents"><i class="ti-truck"></i>Document Categories</a>
                            </li>
                        </ul>
                    </li>
                                       
                     <li class="label">My Profile</li>
                      <?php if($page_title=='Profile Setting'){?>
                            <li class="active">
                            <?php } else { ?><li> <?php }?>
                        <a href="<?php echo base_url();?>Subadmin/profile" class="">
                            <i class="ti-settings"></i> Profile Setting</a>
                            <ul>
                                <li>
                                    <a href="<?php echo base_url();?>Subadmin/profile"><i class="ti-settings"></i> Profile Setting</a>
                                </li>
                            </ul>
                    </li>
                   
                    <li><a href="<?php echo base_url();?>Subadmin/logout"><i class="ti-power-off"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </div>