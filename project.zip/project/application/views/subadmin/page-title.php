   <div class="row">
                    <div class="col-lg-8 p-r-0 title-margin-right">
                        <div class="page-header">
                            <div class="page-title">
                                <h1><span> <b><a href="<?php echo base_url();?>">Home</a></b>  / <?php echo $page_title;?></span></h1>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                    <div class="col-lg-4 p-l-0 title-margin-left">
                        <div class="page-header">
                            <div class="page-title">
<!--                                <ol class="breadcrumb text-right">
                                    <li><a href="<?php echo base_url();?>Adminity">Home</a></li>
                                    <li class="active"><?php echo $page_title;?></li>
                                </ol>-->
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                </div>