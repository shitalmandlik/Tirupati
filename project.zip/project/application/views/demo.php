
<head>
<title>Upload Form</title>
</head>
<body>
<?php echo form_open_multipart('Make/doupload');?>
<?php 
for($i=1;$i<=3;$i++)
{
	?>
<input name="userfile[]" id="userfile" type="file" multiple="form-data" />
<?php
}
?>

<input type="submit" value="upload" />
<?php echo form_close() ?>
</body>
</html>