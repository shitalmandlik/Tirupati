<?php include 'header-top.php';?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/custom.css">
<body>

    <!-- # sidebar -->
    <?php include 'sidebar.php';?>
    <!-- /# sidebar -->


    <!-- # header -->
    <?php include 'header.php';?>
    <!-- /# header -->
    <div class="abchide">
    </div>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
               <!---page title-->
                <?php include 'page-title.php';?>
                <!---/page-title--->
                <!-- /# row -->
                <section id="main-content">
                     <!---system messages---->                    
                    <?php include 'system_msgs.php';?>
                    <!---/system messages---->
                    
                    <div class="row ">
                        <div class="col-lg-12">
                            
                           <div class="card alert">
                                <div class="bootstrap-data-table-panel">
                                    <div class="table-responsive">
                                        
                                    <table id="bootstrap-data-table-export" class="table table-striped table-bordered data">
                                 
                                            <thead>
                                                <tr>
                                                    <th>SR.</th>
                                                    <th>Date</th>
                                                    <th>Register No.</th>
                                                    <th>Starting Km</th>
                                                    <th>Fueling</th>
                                                    <th>Average</th>
                                                    <th style="text-align: left">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $sr=1;
                                        
                                                 foreach($fuel_report as $row){
                                                 
                                                    ?>
                                                <tr>

                                                    <td><?php echo $sr;?></td>
                                                    <td><?php echo $row['date'];?></td>
                                                    <td> <?php echo $row['register_number']; 
                                                    
                                                if($row['prev_km']==0)
                                                    {
                                                            $res=0;
                                                    }
                                                    else
                                                    {
                                                 $res=($row['current_km']-$row['prev_km'])/$row['prev_fuel'];
                                              
                                                     }
                                                
                                                    ?> 
                                                        
                                                    </td>
                                                    <td><?php echo $row['current_km'];?></td>
                                                     <td><?php echo $row['current_fuel'];?></td>

                                                      <td><?php   echo round($res,2);   ?></td>
                                                    <td style="text-align: left">
                                                        <a style="cursor:pointer" onclick="showAjaxModal('<?php echo base_url();?>Adminity/popup/myadmin/viewVehicalDetails/<?php echo $row->vehical_id;?>');" class="table-link">
                                                        <span  class="fa-stack">
                                                        <i class="fa fa-square fa-stack-2x"></i>
                                                        <i class="ti-eye ti-eyes fa-stack-1x fa-inverse"></i>
                                                        </span>
                                                        </a>
                                                        
                                                        <a style="cursor:pointer" onclick="showAjaxModal('<?php echo base_url();?>Adminity/popup/myadmin/editVehical/<?php echo $row->vehical_id;?>');" class="table-link">
                                                        <span  class="fa-stack">
                                                        <i class="fa fa-square fa-stack-2x"></i>
                                                        <i class="ti-pencil-alt ti-pencil-al fa-stack-1x fa-inverse"></i>
                                                        </span>
                                                        </a>
                                                        
                                                        <!--<a  href="<?php echo base_url(); ?>Adminity/subadmin/delete/<?php echo $row->subadmin_id;?>" class="table-link danger">
                                                        <span class="fa-stack" onclick="return checkDelete();">
                                                        <i class="fa fa-square fa-stack-2x"></i>
                                                        <i class="ti-close ti-clos fa-stack-1x fa-inverse"></i>
                                                        </span>
                                                        </a>-->
                                                    </td>
                                                </tr>
                                                <?php $sr++;  }?>    
                                                
                                            </tbody>
                                  

                                        </table>
                                    </div>

                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                    <!-- /# row -->
                    <!--FOOTER CONTENTS--->
                     <?php include 'footer-contents.php';?>
                    <!---/FOOTER CONTENTS-->
                </section>
            </div>
        </div>
    </div>



     <!-- # footer -->
    <?php include 'footer.php';?>
    <!-- /# footer -->
    <script>
     $(function()
      {
        $("#bootstrap-data-table-export").addClass('abc');
        $("#bootstrap-data-table-export_info").addClass('abc');
          $("#bootstrap-data-table-export_info").addClass('abc');
        $("#bootstrap-data-table-export_paginate").addClass('abc');
       $("input[type=search]").addClass('findcls');
        $('.findcls,label').remove();
      $(".abc").hide();

           $(".subbtn").click(function()
           {
             $(".abc").show();
           });
               
           
    $('.bootstrap-data-table-panel').after('<form method ="post" action="<?php echo base_url(); ?>Adminity/fuelResult"><div class="row"><div class="col-md-3"><div class="basic-form"><div class="form-group"><label>Select Vehical</label><input type="search" autocomplete="off" onkeyup="searchData();" id="search-data" placeholder="EX: MH-12-AB-1234" class="form-control" value="" name="register_number"><ul class="result"></ul> </div></div></div><div class="col-md-3"><div class="basic-form"><div class="form-group"><label>From</label> <input type="date"    class="form-control border-none input-flat  bg-ash"  name="from_date"></div></div></div><div class="col-md-3"><div class="basic-form"> <div class="form-group"><label>To</label><input type="date"   class="form-control border-none input-flat  bg-ash" placeholder="Starting kilometer" name="to_date"></div></div></div><div class="col-md-3"><div class="basic-form"> <div class="form-group"><label style="visibility:hidden">to</label><input type="submit" style="width:100px"  class="form-control btn-info subbtn" value="Search"></div></div></div></div></form>');
       });
      function hidetab(){    
            $('#mssg').hide();

          }
           setTimeout(hidetab,4000);


           function searchData(){

        $search = $("#search-data").val();
        
        if($search !='')
        {
        $('.result').addClass('disp');
         $('.result').html("<li class='search-product'><img width='25' src='<?php echo base_url(); ?>mypanel/assets/img/loading.gif'></img></li>");
       $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Adminity/vehicalData",
            data: { search: $search },
            dataType: "json",
            success: function (data) { 
                if (data.length > 0) {                   
                  $('.result').empty();                  
                     $.each(data, function (key,value) {
                         var number= value['register_number'];
                            var id= value['vehicle_id'];

                         $('.result').append('<li class="search-product" onclick="addresult(\''+number+'\');">' + number + '</li>');
                     });
                }
                else{
                     $('.result').html('<li class="search-product"> No Record Found..!</li>');                      
                }
               
            } 
            });
        }

    }
function addresult(str)
{
    $("#search-data").val(str);
    $(".search-product").hide();
}
    </script>

</body>


</html>