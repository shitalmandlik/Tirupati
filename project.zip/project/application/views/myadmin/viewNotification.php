<script src="<?php echo base_url();?>mypanel/assets/js/lib/jquery.min.js"></script>
<script >
     $('.abc').click(function(){
     location.reload();
     });

     $(document).click(function() {
 location.reload();
 
        });

</script>
<?php 
$cat_id= $this->uri->segment(5);
$vehical_id= $this->uri->segment(6);
$this->db->select('*');
$this->db->from('document_tbl');
$this->db->where('category_id',$cat_id);
//$this->db->where('vehical_id',$vehical_id);
$document_info = $this->db->get()->result_array();

$cnt=0;
?>
<style>
        .required{
            color:red;
        }
    </style>
    <section id="main-content">
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Details</h4>                                        
                                    </div>
                                </div>
                                
                              <?php
                              foreach ($document_info as  $value)
                                {
                                if($value['vehical_id']==$vehical_id && $value['category_id']==$cat_id)
                                    {
                                        $date=$value['expiry_date'];
                                  
                                    $date=date_create($date);
                                    $today=date_create();
                                    $diff   = date_diff($today,$date );
                                    $diff1=$diff->format("%R%a");
                                    if($diff1<30)
                                        {                    
                                    $arr=explode("/",$value['file_name']);
                                    $new_file=$arr[0];
                                    echo "<b><span style='color:green;'>Your ".$new_file." will be Expire on </span><b style='color:red'><u>"
                                    .$value['expiry_date']."</u><b><br>"; 

                                    $id=$value['category_id'];
                                    $date1=$value['expiry_date'];
                                    $this->db->set('status','1',false);
                                    $this->db->where('category_id',$id);
                                    $this->db->where('expiry_date',$date1);
                                    $this->db->update('document_tbl');
                                            
                                             $cnt++; 
                                         }  
                                    }
                                }
                               ?>
                                    
                                    
                                <div class="row">
                                  
                                    <div class="modal-footer"  style="border: none;">
                                        <button type="button" onClick="PrintElem('main-content')" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-printer"></i> Print</button>
                                            <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn abc" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                        </div> 
                                </div>                                
                              
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
   </section>

    <!-- scripit init-->

<script type="text/javascript">
 function PrintElem(el){
    
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
        
	window.print();
        
	document.body.innerHTML = restorepage;
        window.location.reload();
      // return true;
}
</script>  