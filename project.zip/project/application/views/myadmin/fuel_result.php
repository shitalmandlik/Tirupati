<?php include 'header-top.php';?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/custom.css">
<body>

    <!-- # sidebar -->
    <?php include 'sidebar.php';?>
    <!-- /# sidebar -->


    <!-- # header -->
    <?php include 'header.php';?>
    <!-- /# header -->
    <div class="abchide">
    </div>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
               <!---page title-->
                <?php include 'page-title.php';?>
                <!---/page-title--->
                <!-- /# row -->
                <section id="main-content">
                     <!---system messages---->                    
                    <?php include 'system_msgs.php';?>
                    <!---/system messages---->
                    
                    <div class="row ">
                        <div class="col-lg-12">
                            
                           <div class="card alert">
                                <div class="bootstrap-data-table-panel">
                                    <div class="table-responsive">
                                        
                                    <table id="bootstrap-data-table-export" class="table table-striped table-bordered data">
                                 
                                            <thead>
                                                <tr>
                                                    <th>SR.</th>
                                                    <th>Date</th>
                                                    <th>Register No.</th>
                                                    <th>Starting Km</th>
                                                    <th>Fueling</th>
                                                    <th style="float: left">Average</th>

                                                  
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $sr=1;
                                        
                                                 foreach($fuel_report as $row){
                                                 
                                                    ?>
                                                <tr>

                                                    <td><?php echo $sr;?></td>
                                                    <td><?php echo $row['date'];?></td>
                                                    <td> <?php echo $row['register_number']; 
                                                    
                                                if($row['prev_km']==0)
                                                    {
                                                            $res=0;
                                                    }
                                                    else
                                                    {
                                                 $res=($row['current_km']-$row['prev_km'])/$row['prev_fuel'];
                                              
                                                     }
                                                
                                                    ?> 
                                                        
                                                    </td>
                                                    <td><?php echo $row['current_km'];?></td>
                                                   
                                                     <td><?php echo $row['current_fuel'];?></td>
                                                     
                                                      <td><?php   echo $avg=round($res,2);   ?></td>
                                                   

                                                </tr>

                                                <?php $sr++; $fuel[]=$row['current_fuel'];
                                                  $km[]=$row['current_km'];
                                            
                                                  $total_avg[]=$avg;
                                                  $c=count($total_avg)-1;
                                                  
                                              }?>    
                                              
                                            </tbody>
                                                <tr >
                                                <td><b>Total</b></td><td></td><td></td>
                                                <td> <b><?php echo end($km)-$km[0];  ?></b></td>
                                                <td><b><?php echo array_sum($fuel); ?></b></td>
                                                <td><b><?php $sum=array_sum($total_avg); echo round($sum/$c,2); ?></b></td>
                                               </tr>
                                        </table>
                                    </div>

                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                    <!-- /# row -->
                    <!--FOOTER CONTENTS--->
                     <?php include 'footer-contents.php';?>
                    <!---/FOOTER CONTENTS-->
                </section>
            </div>
        </div>
    </div>
      <?php include 'footer.php';?>

      <script >
       $(function()
      {
         
        $("input[type=search]").addClass('abc');
        $('.abc,label').remove();
      });
      </script>