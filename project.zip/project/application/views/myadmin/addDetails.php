<?php 
$vehical_info = $this->db->get('vehicaldetails_tbl')->result_array();
//$insurance_info=$this->db->get('category_tbl')->result_array();
?>
<!-- Styles -->
    <link href="<?php echo base_url();?>mypanel/assets/css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    
    <script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>    
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
    <script >
        $ (document).ready(function () {
            $(".fill-block").hide();
            $("#selectBox").change(function()
            {
                  $(".fill-block").show();     
            })
         });

    </script>
    <script >
        function searchData(str)
        {
            $(document).ready(function () {
            $.ajax({
            url: "<?php echo base_url();?>Adminity/searchData",
            type: "POST",
            data:  {'reg_number':str},
            success: function(data){
            //$("#rec").html(data);
            $("#suggesstion-box").html(data);
            },
            error: function(){}             
                });
           });
        }
        function selectCountry(val) {
$("#searchBox").val(val);
$("#suggesstion-box").hide();
}
    </script>
<script type="text/javascript">
$(document).ready(function (e) {

    $("#uploadForm").on('submit',(function(e) 
    {
        e.preventDefault();
        $.ajax({
            url: "<?php echo base_url();?>Upload",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
            //$("#gallery").html(data);
            window.location.href = data.'<?php echo "";?>';
            },
            error: function(){}             
       });
    }));
    
});

</script>
       <section id="main-content">
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Add Details</h4>                                        
                                    </div>
                                </div>
                                <form action="<?php echo base_url();?>Upload" method="post" enctype="multipart/form-data" id="uploadForm">  
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                            <label>Select Vehical</label>
                                            <input type="search" name="reg_number" placeholder="Ex: MH-12-AV-1234" onkeyup="searchData(this.value)" id="searchBox">
                                            <div id="suggesstion-box"></div>
                                             <select class="form-control"  name="reg_number"  id="selectBox">
                                            <option value="" >-Select-</option>
                                                        <?php foreach ($vehical_info as $row) 
                                                        {
                                                            ?>
                                                            
                                         <option value="<?php echo $row['register_number'];?>"><?php echo $row['register_number'];?></option>
                                                        <?php
                                                    }?>
                                            
                                                    </select>
                                            </div>
                                        </div>
                                    </div>
                                                <div class="fill-block">
                                                    <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                <?php echo $error;?>
                                                                
                                                                    <label>Insurance</label>
                                                                    <input type="file" name="insurance_file" >
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                <?php echo $error;?>
                                                                    <label>Expiry Date</label>
                                                                    <input type="date" class="form-control" name="insurance_exp" >
                                                            </div>
                                                        </div>
                                                    </div>

                                                     <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                <?php echo $error;?>
                                                                    <label>Notification Before</label>
                                                                    <input type="text" class="form-control" name="insurance_notify" placeholder="In days">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                    <label>R.C.</label>
                                                                    <input  type="file" name="rc_file">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                <?php echo $error;?>
                                                                    <label>Expiry Date</label>
                                                                    <input type="date" class="form-control" name="rc_date" >
                                                            </div>
                                                        </div>
                                                    </div>

                                                     <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                <?php echo $error;?>
                                                                    <label>Notification Before</label>
                                                                    <input type="text" class="form-control" name="rc_notify" placeholder="In days">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                    <label>P.U.C.</label>
                                                                    <input type="file" name="puc_file">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                <?php echo $error;?>
                                                                    <label>Expiry Date</label>
                                                                    <input type="date" class="form-control" name="puc_exp" >
                                                            </div>
                                                        </div>
                                                    </div>

                                                     <div class="col-md-4">
                                                        <div class="basic-form">
                                                            <div class="form-group">
                                                                <?php echo $error;?>
                                                                    <label>Notification Before</label>
                                                                    <input type="text" class="form-control" name="puc_notify" placeholder="In days">
                                                            </div>
                                                        </div>
                                                    </div>

                                               
                                                         
                                                                                           
                                                        <div class="col-md-12">
                                                            <div class="modal-footer">
                                                                <button type="submit" class="btn btn-info btn-lg  border-none sbmt-btn" name="submit_btn"><i class="ti-save"></i> Add Details</button>
                                                                <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                                            </div>  
                                                       </div>
                                                   </div>
                                </div>                                
                                </form>
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
   </section>

    <!-- scripit init-->
