<?php $document_info = $this->db->get_where('document_tbl', array('vehical_id' => $param2))->result_array();
$cat_res=$this->db->query("select * from category_tbl")->result_array();
?>
<style>
        .required{
            color:red;
        }
    </style>
    <section id="main-content">
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Document Information</h4>                                        
                                    </div>
                                </div>
                                <div class="row">
                                     <table class="table table-bordered" style="">                       
                                        <tr>
                                           <?php foreach($cat_res as $category){
                                                    ?>
                                                    <th><?php echo $category['category_name'];?></th>
                                                    <?php } ?>
                                        </tr>
                                        <tr>
                                          <?php
                                            foreach ($document_info as $row) {
                                               
                                                ?>   
                                            <?php 
                                            $arr=explode("/",$row['file_name']);
                                            $new_file=end($arr);
                                            if (!empty($new_file)) { ?>
                                            <td >
                                       
                                         <?php $name=explode(".",$new_file); ?>
                                         <a href="<?php echo base_url();?>Adminity/download/<?php echo $row['vehical_id'].'/'.$row['category_id']; ?>" target="_blank"><b style="color:blue"><?php echo $name[0]; ?> </b></a>
                                            </td>

                                                <?php }else{ ?><td>Document is not uploaded</td>
                                                <?php } }  ?>
                                        </tr>
                                    
                                    
                                </table>  

                                    <div class="modal-footer">
                                        <button type="button" onClick="PrintElem('main-content')" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-printer"></i> Print</button>
                                            <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                        </div> 
                                </div>                                
                              
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
   </section>

    <!-- scripit init-->

<script type="text/javascript">
 function PrintElem(el){
    
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
        
	window.print();
        
	document.body.innerHTML = restorepage;
        window.location.reload();
      // return true;
}
</script>  