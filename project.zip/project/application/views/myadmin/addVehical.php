<!-- Styles -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link href="<?php echo base_url();?>mypanel/assets/css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
       <section id="main-content">
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Add Vehical Details</h4>                                        
                                    </div>
                                </div>
                                <form action="<?php echo base_url();?>Adminity/vehicalDetails/addVehical" method="post" enctype="multipart/form-data">   
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Owner Name <span class="required">*</span></label>
                                                    <input type="text"  name="owner_name" required="" class="form-control border-none input-flat  bg-ash" placeholder="Owner Name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Register Number<span class="required">*</span></label>
                                                    <input type="text"  name="register_number" required=""   class="form-control border-none input-flat  bg-ash" placeholder="Eg: MH-12-AB-7909" id="reg_number" >
                                            </div>
                                        </div>
                                    </div>
                                   
                                   <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Seat Quantity<span class="required">*</span></label>
                                                    <input type="text"  name="seat_quantity" required="" pattern="[0-9]"  class="form-control border-none input-flat  bg-ash" placeholder="Seat Quantity">
                                            </div>
                                        </div>
                                    </div>
<?php $cat_info = $this->db->get('category_tbl')->result_array();
 foreach ($cat_info as $row) {
?>
                 <input type="hidden" name="cat_id[]" value="<?php echo $row['category_id'];?>">
                 <div class="col-md-4">
                                    <div class="basic-form">
                                        <div class="form-group">
                                            <?php echo $error;?>
                                                <label><?php echo $row['category_name'];?></label>

                                                <input type="file" name="doc_name[]" >
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="basic-form">
                                        <div class="form-group">
                                            <?php echo $error;?>
                                                <label>Expiry Date</label>
                                                <input type="date" class="form-control" name="doc_expiry[]" >
                                        </div>
                                    </div>
                                </div>

                                 <div class="col-md-4">
                                    <div class="basic-form">
                                        <div class="form-group">
                                            <?php echo $error;?>
                                                <label>Notification Before</label>
                                                <input type="text" class="form-control" name="doc_notify[]" placeholder="In days">
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                                                   
                                    <div class="col-md-12">
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-save"></i> Add Details</button>
                                            <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                        </div>  
                                   </div>
                                </div>                                
                                </form>
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
   </section>

    <!-- scripit init-->
    <script type="text/javascript">
 $(document).ready(function() 
 {
        $("#reg_number").keyup(function(){
         
            this.value = this.value.toUpperCase();
        })
})

        </script>