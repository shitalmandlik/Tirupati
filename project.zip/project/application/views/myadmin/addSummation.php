<?php include 'header-top.php';?>

<body>

    <!-- # sidebar -->
    <?php include 'sidebar.php';?>
    <!-- /# sidebar -->


    <!-- # header -->
    <?php include 'header.php';?>
    <!-- /# header -->
    
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
               <!---page title-->
                <?php include 'page-title.php';?>
                <!---/page-title--->
                <!-- /# row -->
                <section id="main-content">
                     <!---system messages---->                    
                    <?php include 'system_msgs.php';?>
                    <?php  
                            $sites=$this->db->get('sites')->result(); 
                            $sumlist=$this->db->get('sumlist_table')->result(); 
                            $owner = $this->db->get('vehicle_owner')->result_array();
                            $vehicle = $this->db->get('tbl_vehicle')->result_array();
                            ?>
<!-- Styles -->

 <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
 
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Add Summation</h4>                                        
                                    </div>
                                </div>
                                <form action="<?php echo base_url();?>Adminity/summation/makesum" method="post">   
                                <div class="row">                                   
                                    
                                   <div class="col-md-6">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                <label>Select Vehicle <span class="required">*</span></label>
                                                <br>
                                                <select class="form-control selectpicker" data-live-search="true" required="" name="vehicle_id" id="vehicle_id" onchange="loadVehicleDate(this.value);">
                                                     <option value="">---Select Vehicle--- </option>
                                                     <?php
                                                    foreach($vehicle as $row)
                                                    {?>
                                                     <option value="<?php echo $row['vehicle_id'];?>"><?php echo $row['vehicle_no'];?></option>
                                                    <?php }
                                                    ?>
                                                </select> 
                                               
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                <label>Vehicle Owner <span class="required">*</span></label>
                                                <select class="form-control etype" required="" name="vehicle_owner_id"  id="vehicle_owner_id">
                                                  
                                                </select> 
                                               
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="basic-form">
                                        <div class="col-md-6">
                                            <div class="form-group">                                            	
                                                <label>Route <span class="required">*</span></label>
                                               <input type="text" class="form-control" name="route" required="" placeholder="Route: 1/1">
                                               </div>
                                            </div>
                                           
                                            <div class="col-md-6">
                                            	<div class="form-group">
                                                <label>Month <span class="required">*</span></label>
<!--                                                <select class="form-control" required="">
                                                    <option></option>
                                                </select>-->
                                               <input type="month" class="form-control" name="month" required="">
                                               </div>
                                            </div>
                                     	</div>
                                    </div>
                                    
                                     <div class="col-md-6">
                                        <div class="basic-form">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>From <span class="required">*</span></label>
                                               <input type="date" class="form-control" name="from" required="">
                                               </div>
                                         </div>
                                         <div class="col-md-6">
                                            <div class="form-group">
                                                <label>To <span class="required">*</span></label>
                                               <input type="date" class="form-control" name="to" required="">
                                               </div>
                                         </div>
                                        </div>
                                    </div>
                                      
                                    <div class="col-md-3">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Select Company: <span class="required">*</span></label>                                                    
                                            </div>
                                        </div>
                                    </div>
                                     <div class="col-md-9"> 
                                                        <?php                       
                                                        foreach($sites as $each)
                                                        { 
                                                         ?>                                         
                                                        <div class="col-md-6">                                                            
                                                        <div class="basic-form">
                                                           <div class="form-group">
                                                               <input type="checkbox" style="height: 17px;width: 17px;" name="site_id[]" value="<?php echo $each->site_id;?>"> <?php echo $each->site_name;?>
                                                           </div>
                                                        </div>
                                                        </div>                                                        
                                                        <?php }
                                                        ?> 
                                         </div> 
                                    <div class="col-md-12">
                                        <table class="table table-bordered table-stripped">
                                            <thead>
                                            <tr><th>
                                                #List
                                            </th>
                                            <th style="text-align: left">
                                                Amount(<i class="fa fa-inr"></i>)
                                            </th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                    <?php                       
                                    foreach($sumlist as $sum)
                                    { 
                                     ?>
                                         <tr>
                                             <td><?php echo $sum->sum_name;?> :</td>
                                             <td>
                                                 <input type="hidden" name="sum_id[]" value="<?php echo $sum->sumlist_id; ?>"/>
                                                  <input type="hidden" name="sum_name[]" value="<?php echo $sum->sum_name; ?>"/>
                                                 <input type="text" style="height: 34px;" class="form-control sum" autocomplete="off" name="sum[]" value="0" placeholder="<?php echo $sum->sum_name;?>"></td>
                                       </tr>
                                    <?php }?>
                                       <tr>
                                           <td><b>Sum of Total Amount Due (<i class="fa fa-inr"></i>) :</b></td>
                                           <td><input type="text" name="total" id="" class="form-control" value="0" style="font-size: large;font-weight: 600;" required="" ></td>
                                       </tr>
                                            </tbody>
                                                
                                        </table>
                                    </div>
                                    
                                                                       
                                    <div class="col-md-12">
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-save"></i> Add Summation</button>
                                            <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                        </div>  
                                   </div>
                                </div>                                
                                </form>
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
    <!-- /# row -->
                    <!--FOOTER CONTENTS--->
                     <?php include 'footer-contents.php';?>
                    <!---/FOOTER CONTENTS-->
                </section>
            </div>
        </div>
    </div>

  <?php include 'footer.php';?>
    <!-- scripit init-->
    <script>
        function loadVehicleDate($id){ 
            $.post("<?php echo base_url(); ?>Adminity/getVehicleData",
             {
               vehicle_id : $id,
             },
             function(data)
             {
                 $('#vehicle_owner_id').html(data);
             });
        }
        $(document).ready(function(){
       
        $('.sum').keyup(function(){
             var sum = 0;
             $('.sum').each(function(){
            sum += +$(this).val();          
        });
        $("#thisTotal").val(sum);
        });
    });
       
        </script>

  
    <!-- # footer -->
  
    <!-- /# footer -->
    <script>
       $(document).ready(function() {
           function hidetab(){    
            $('#mssg').hide();
          }
            setTimeout(hidetab,4000);
       });
    </script>

</body>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>
</html>