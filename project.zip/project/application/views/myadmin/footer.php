 <!--    <div id="search">
        <button type="button" class="close">�</button>
        <form>
            <input type="search" value="" placeholder="type keyword(s) here" />
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>--> 
 <!-- jquery vendor -->
    
    <!-- scripit init-->
 <script src="<?php echo base_url();?>mypanel/assets/js/lib/jquery.min.js"></script>
    <!-- jquery vendor -->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/jquery.nanoscroller.min.js"></script>
    <!-- nano scroller -->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/menubar/sidebar.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/preloader/pace.min.js"></script>
    <!-- sidebar -->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/bootstrap.min.js"></script>
    <!-- bootstrap -->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/weather/jquery.simpleWeather.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/weather/weather-init.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/circle-progress/circle-progress.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/circle-progress/circle-progress-init.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/chartist/chartist.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/chartist/chartist-init.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/sparklinechart/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/sparklinechart/sparkline.init.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/scripts.js"></script>
    
      <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/datatables.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/buttons.dataTables.min.html"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/buttons.flash.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/jszip.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/data-table/datatables-init.js"></script>
    
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/sweetalert/sweetalert.min.js"></script>
    <!-- scripit init-->
   <script src="<?php echo base_url();?>mypanel/assets/js/lib/sweetalert/sweetalert.init.js"></script>
   <script >
     
   </script>

    <!-- scripit init-->
    
    