<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>

</script>

<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
        <div class="nano">
            <div class="nano-content">
                <ul>
                     <li class="label">Dashboard</li>
                     <?php if($page_title=='Dashboard'){?>
                    <li class="active">
                    <?php } else { ?><li> <?php }?>
                        <a href="<?php echo base_url();?>" class="">
                            <i class="ti-home"></i> Dashboard </a>
                       
                    </li>
                    
                     <li class="label">Basic</li>
                     <?php if($page_title=='System OTP' || $page_title=='Vehicle Owner' || $page_title=='Vehicles'  || $page_title=='Drivers' || $page_title=='Fuel Pumps' || $page_title=='Sites' || $page_title=='Supervisors' || $page_title=='Subadmin'){?>
                            <li class="active open">
                            <?php } else { ?><li> <?php }?>
                        <a class="sidebar-sub-toggle"><i class="ti-plus"></i>Basic Entries<span class="badge badge-primary">4</span><span class="sidebar-collapse-icon ti-angle-down"></span></a>
                        <ul>

                          <!-- <?php /*if($page_title=='Vehicles'){*/?>
                            <li class="active">
                            <?php /*} else { */?><li> <?php /*}*/?>
                                <a href="<?php /*echo base_url();*/?>Adminity/vehicles"><i class="ti-truck"></i>Vehicles</a>
                            </li>-->

                             <?php if($page_title=='Subadmin'){?>
                            <li class="active">
                            <?php } else { ?><li> <?php }?>
                                 <a href="<?php echo base_url();?>Adminity/addCategory"><i class="fa fa-file-text-o"></i>Add Category</a>
                                 
                                <a href="<?php echo base_url();?>Adminity/vehicalDetails"><i class="fa fa-car"></i>Vehical Registration</a>


                                <a href="<?php echo base_url();?>Adminity/report"><i class="fa fa-file-text-o"></i>Reports</a>

                                <a href="<?php echo base_url();?>Adminity/notification"><i class="fa fa-file-text-o"></i>Notification 
                                    <span class="badge badge-primary">(<?php echo notificationCount(); ?>)</span>
                                </a>
                               
                                  <a href="<?php echo base_url();?>Adminity/report"><i class="fa fa-file-text-o"></i>Reports</a>
                            </li>
                            
                        </ul>
                    </li>

                     <li class="label">My Profile</li>
                      <?php if($page_title=='Profile Setting'){?>
                            <li class="active">
                            <?php } else { ?><li> <?php }?>
                        <a href="<?php echo base_url();?>Adminity/profile" class="">
                            <i class="ti-settings"></i> Profile Setting</a>
                            <ul>
                               

                                <li>
                                    <a href="<?php echo base_url();?>Adminity/profile"><i class="ti-settings"></i> Profile Setting</a>
                                </li>
                            </ul>
                    </li>
                    <li class="active">
                                <a href="<?php echo base_url();?>Adminity/fuelInfo" ><img src="<?php echo base_url(); ?>assets/img/fuel.png" width="20" height="20">Fueling</a>
                                </li>
                                 <li class="active">
                                <a href="<?php echo base_url();?>Adminity/fuelReport" ><i class="fa fa-file-text-o"></i>Fuel Reports</a>
                                </li>
                    <li><a href="<?php echo base_url();?>Adminity/logout"><i class="ti-power-off"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </div>