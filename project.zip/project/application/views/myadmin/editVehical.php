<?php $vehical_info = $this->db->get_where('vehicaldetails_tbl', array('vehical_id' => $param2))->result_array();
$id= $this->uri->segment(5);
$data=$this->db->query("select * from  document_tbl t1 join category_tbl t2 on t1.category_id=t2.category_id where vehical_id='$id'")->result_array();

 foreach ($vehical_info as $row) {
?><!-- Styles -->
    <link href="<?php echo base_url();?>mypanel/assets/css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
       <section id="main-content">
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Update Vehical Details</h4>                                        
                                    </div>
                                </div>
                                <form action="<?php echo base_url();?>Adminity/vehicalDetails/editVehical/<?php echo $row['vehical_id'];?>" method="post">   
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Owner Name <span class="required">*</span></label>
                                                    <input type="text"  name="owner_name" value="<?php echo $row['owner_name'];?>" required="" class="form-control border-none input-flat  bg-ash" placeholder="Owner Name">
                                            </div>
                                        </div>
                                    </div>
                                     <div class="col-md-4">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Register Number<span class="required">*</span></label>
                                                    <input type="text"  name="register_number" value="<?php echo $row['register_number'];?>" required=""   class="form-control border-none input-flat  bg-ash" placeholder="Eg: MH-12-AB-7909">
                                            </div>
                                        </div>
                                    </div>
                                   
                                   <div class="col-md-4">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                    <label>Seat Quantity<span class="required">*</span></label>
                                                    <input type="text" value="<?php echo $row['seat_quantity'];?>" name="seat_quantity" required="" pattern="[0-9]"  class="form-control border-none input-flat  bg-ash" placeholder="Seat Quantity">
                                            </div>
                                        </div>
                                    </div>
                                     <?php 
                                     foreach ($data as $row1) {
                                       
                            ?>
                 <input type="hidden" name="cat_id[]" value="<?php echo $row1['category_id'];?>">
                 <div class="col-md-4">
                                    <div class="basic-form">
                                        <div class="form-group">
                                            <?php echo $error;?>
                                                <label><?php echo $row1['category_name'];?></label>
                                                <input type="file" name="doc_name[]" value="<?php  $file=explode('/',$row1['file_name']); echo $file[1];?>">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="basic-form">
                                        <div class="form-group">
                                            <?php echo $error;?>
                                                <label>Expiry Date</label>
                                                <input type="date" class="form-control" name="doc_expiry[]" value="<?php echo $row1['expiry_date'];?>">
                                        </div>
                                    </div>
                                </div>

                                 <div class="col-md-4">
                                    <div class="basic-form">
                                        <div class="form-group">
                                            <?php echo $error;?>
                                                <label>Notification Before</label>
                                                <input type="text" class="form-control" name="doc_notify[]" placeholder="In days" value="30">
                                        </div>
                                    </div>
                                </div>
                                <?php }  ?>          
                                                                       
                                    <div class="col-md-12">
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-pencil-alt"></i> Update Vehical Details</button>
                                            <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                        </div>  
                                   </div>
                                </div>                                
                                </form>
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
   </section>
 <?php }?>
    <!-- scripit init-->
