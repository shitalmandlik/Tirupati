<?php include 'header-top.php';?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/custom.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<body>

    <!-- # sidebar -->
    <?php include 'sidebar.php';?>
    <!-- /# sidebar -->


    <!-- # header -->
    <?php include 'header.php';?>
    <!-- /# header -->
    
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
               <!---page title-->
                <?php include 'page-title.php';?>
                <!---/page-title--->
                <!-- /# row -->
                <section id="main-content">
                     <!---system messages---->                    
                    <?php include 'system_msgs.php';?>
                    <!---/system messages---->
                    
                    <div class="row">
                        <div class="col-lg-12">
                            <!--<div class="addbtn">
                                <button data-toggle="modal" onclick="showAjaxModal('<?php echo base_url();?>Adminity/popup/myadmin/addVehical');" class="btn btn-primary" > </button>
                             </div>-->
                   <div class="card alert">
                        <div class="bootstrap-data-table-panel">
                            <div class="table-responsive">
                                <form action="<?php echo base_url();?>Adminity/fuelInfo/addFuel" method="post">   
                        <div class="row">
                            <div class="col-md-6">
                                <div class="basic-form">
                                    <div class="form-group">
                                        <label>Select Vehical<span class="required">*</span></label>
                                        <input type="search" autocomplete="off" onkeyup="searchData();" id="search-data" placeholder="EX: MH-12-AB-1234" class="form-control" value="" name="register_number">
                                        
                                         <ul class="result" style="width: 97%;"></ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="basic-form">
                                    <div class="form-group">
                                            <label>Date</label>
                                             <input type="date"    class="form-control border-none input-flat  bg-ash" placeholder="Category Name"  value="<?php echo date('y-m-d'); ?>" name="date">
                                    </div>
                                </div>
                            </div>
                           <div class="col-md-6">
                                <div class="basic-form">
                                    <div class="form-group">
                                            <label>Starting KM. <span class="required">*</span></label>
                                            <input type="text"   required="" class="form-control border-none input-flat  bg-ash" placeholder="Starting kilometer" name="start_km">
                                    </div>
                                </div>
                            </div>
                             <div class="col-md-6">
                                <div class="basic-form">
                                    <div class="form-group">
                                            <label>Fuel<span class="required">*</span></label>
                                            <input type="text"   required="" class="form-control border-none input-flat  bg-ash" placeholder="Fuel in litre" name="fuel">
                                    </div>
                                </div>
                            </div>
                                                               
                            <div class="col-md-12">
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-save"></i> Add Details</button>
                                    
                                </div>  
                           </div>
                        </div>                                
                        </form>
                            </div>
                        </div>
                    </div>
                    <!-- /# card -->
                </div>
                <!-- /# column -->
            </div>
                    <!-- /# row -->

                    <!-- /# row -->
                    <!--FOOTER CONTENTS--->
                     <?php include 'footer-contents.php';?>
                    <!---/FOOTER CONTENTS-->
                </section>
            </div>
        </div>
    </div>



     <!-- # footer -->
    <?php include 'footer.php';?>
    <!-- /# footer -->
    <script>
       $(document).ready(function() {
        $("#search-data").keyup(function(){
         
            this.value = this.value.toUpperCase();
        })
           function hidetab(){    
            $('#mssg').hide();
          }
            setTimeout(hidetab,4000);
       });
       function searchData(){

        $search = $("#search-data").val();
        
        if($search !='')
        {
        $('.result').addClass('disp');
         $('.result').html("<li class='search-product'><img width='25' src='<?php echo base_url(); ?>mypanel/assets/img/loading.gif'></img></li>");
       $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Adminity/vehicalData",
            data: { search: $search },
            dataType: "json",
            success: function (data) { 
                if (data.length > 0) {                   
                  $('.result').empty();                  
                     $.each(data, function (key,value) {
                         var number= value['register_number'];
                            var id= value['vehicle_id'];

                         $('.result').append('<li class="search-product" onclick="addresult(\''+number+'\');">' + number + '</li>');
                     });
                }
                else{
                     $('.result').html('<li class="search-product"> No Record Found..!</li>');                      
                }
               
            } 
            });
        }

    }
function addresult(str)
{
    $("#search-data").val(str);
    $(".search-product").hide();
}

    </script>

</body>


</html>