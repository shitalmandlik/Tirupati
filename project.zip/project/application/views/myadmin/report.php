<?php
$vehical_res=$this->db->query("select * from vehicaldetails_tbl")->result_array();
$cat_res=$this->db->query("select * from category_tbl")->result_array();

?>
<?php include 'header-top.php';?>

<body>

    <!-- # sidebar -->
    <?php include 'sidebar.php';?>
    <!-- /# sidebar -->


    <!-- # header -->
    <?php include 'header.php';?>
    <!-- /# header -->
    
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
               <!---page title-->
                <?php include 'page-title.php';?>
                <!---/page-title--->
                <!-- /# row -->
                <section id="main-content">
                     <!---system messages---->                    
                    <?php include 'system_msgs.php';?>
                    <!---/system messages---->
                    
                    <div class="row">
                        <div class="col-lg-12">
                           
                           <div class="card alert">
                                <div class="bootstrap-data-table-panel">
                                    <div class="table-responsive">
                                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>SR.</th>
                                                    <th>Owner Name</th>
                                                    <th>Register No.</th>
                                                    <?php foreach($cat_res as $category){
                                                    ?>
                                                    <th><?php echo $category['category_name'];?> expiry Date</th>
                                                    <?php } ?>
                                                    

                                                    <th style="text-align: left">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                              foreach ($vehical_res as $key=>$value) { ?>
                                                
                                                <tr>
                                                    <td><?php echo $key+1;?></td>
                                                    <td><?php echo $value['owner_name'];?></td>
                                                    <td><?php echo $value['register_number'];?></td>


                                    <?php $id=$value['vehical_id'];
                                    echo $id;
                                $getdata=$this->db->query("select * from document_tbl where vehical_id=$id")->result_array();
                                foreach ($getdata as $getrow) { ?>

                                <?php if (!empty($getrow['expiry_date'])) { ?>
                                     <td><?php echo $getrow['expiry_date']; ?></td>
                               <?php }else{ ?>
                                     <td>Expiry Date is empty</td>
                                  <?php } ?>

                                 <?php  } ?>
    
                                                    <td style="text-align: left">
                                                        <a style="cursor:pointer" onclick="showAjaxModal('<?php echo base_url();?>Adminity/popup/myadmin/viewReport/<?php echo $value['vehical_id'];?>');" class="table-link">
                                                        <span  class="fa-stack">
                                                        <i class="fa fa-square fa-stack-2x"></i>
                                                        <i class="ti-eye ti-eyes fa-stack-1x fa-inverse"></i>
                                                        </span>
                                                        </a>
                                                        
                                                        <a style="cursor:pointer" onclick="showAjaxModal('<?php echo base_url();?>Adminity/popup/myadmin/editReport/<?php echo $value['vehical_id'];?>');" class="table-link">
                                                        <span  class="fa-stack">
                                                        <i class="fa fa-square fa-stack-2x"></i>
                                                        <i class="ti-pencil-alt ti-pencil-al fa-stack-1x fa-inverse"></i>
                                                        </span>
                                                        </a>
                                                        
                                                        <!--<a  href="<?php echo base_url(); ?>Adminity/subadmin/delete/<?php echo $row->subadmin_id;?>" class="table-link danger">
                                                        <span class="fa-stack" onclick="return checkDelete();">
                                                        <i class="fa fa-square fa-stack-2x"></i>
                                                        <i class="ti-close ti-clos fa-stack-1x fa-inverse"></i>
                                                        </span>
                                                        </a>-->
                                                    </td>
                                                </tr>
                             <?php  }?>    
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                    <!-- /# row -->
                    <!--FOOTER CONTENTS--->
                     <?php include 'footer-contents.php';?>
                    <!---/FOOTER CONTENTS-->
                </section>
            </div>
        </div>
    </div>



     <!-- # footer -->
    <?php include 'footer.php';?>
    <!-- /# footer -->
    <script>
       $(document).ready(function() {
           function hidetab(){    
            $('#mssg').hide();
          }
            setTimeout(hidetab,4000);
       });
    </script>

</body>


</html>