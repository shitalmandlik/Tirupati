<?php
date_default_timezone_set('Asia/Kolkata');
$data=$this->db->query("select * from vehicaldetails_tbl t1  join document_tbl t2 on t1.vehical_id=t2.vehical_id join category_tbl t3 on t2.category_id=t3.category_id")->result_array();
$cnt=1;
?>
<body class="xyz">
<?php include 'header-top.php';?>


    <!-- # sidebar -->
    <?php include 'sidebar.php';?>
    <!-- /# sidebar -->


    <!-- # header -->
    <?php include 'header.php';?>
    <!-- /# header -->
    
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
               <!---page title-->
                <?php include 'page-title.php';?>
                <!---/page-title--->
                <!-- /# row -->
                <section id="main-content">
                     <!---system messages---->                    
                    <?php include 'system_msgs.php';?>
                    <!---/system messages---->
                    
                    <div class="row">
                        <div class="col-lg-12">
                           
                           <div class="card alert">
                                <div class="bootstrap-data-table-panel">
                                    <div class="table-responsive">
                                        <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    
                                                    <th>Owner Name</th>
                                                    <th>Register No.</th>
                                                    <th>Category Name</th>
                                                    <th>Expiry Date</th>
                                                    <th style="text-align: left">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                            <?php  foreach ($data as $key => $value)
                             {
                                if(!empty($value['expiry_date']))
                                {
                                    $date=$value['expiry_date'];
                                    $date=date_create($date);
                                    $today=date_create();
                                    $diff   = date_diff($today,$date );
                                    $diff1=$diff->format("%R%a");
                                    if($diff1<30)
                                        { ?>
                                            <tr>
                                            <td><?php echo $value['owner_name']; ?></td>
                                            <td><?php echo $value['register_number']; ?></td>
                                             <td><?php echo $value['category_name']; ?></td>
                                             <td><?php echo $value['expiry_date']; ?></td>
                                            <td style="text-align: left">
                                            <a style="cursor:pointer" onclick="showAjaxModal('<?php echo base_url();?>Adminity/popup/myadmin/viewReport/<?php echo $value['vehical_id'];?>');" class="table-link">
                                            <span  class="fa-stack">
                                            <i class="fa fa-square fa-stack-2x"></i>
                                            <i class="ti-eye ti-eyes fa-stack-1x fa-inverse"></i>
                                            </span>
                                            </a>
                                            
                                    <a style="cursor:pointer" onclick="showAjaxModal('<?php echo base_url();?>Adminity/popup/myadmin/viewNotification/<?php echo $value['category_id'];?>/<?php echo $value['vehical_id'];?>');" class="table-link">
                                        <img src="<?php echo base_url(); ?>/assets/img/read.png" width="30" height="30" ></a>
                                        
                                        </td>
                                        <?php $cnt++; }  ?>
                                    <?php 
                                    }
                                
                                }
                                ?>
                                                    
                                                </tr>    
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>
                    <!-- /# row -->

                    <!-- /# row -->
                    <!--FOOTER CONTENTS--->
                     <?php include 'footer-contents.php';?>
                    <!---/FOOTER CONTENTS-->
                </section>
            </div>
        </div>
    </div>



     <!-- # footer -->
    <?php include 'footer.php';?>
    <!-- /# footer -->
    <script>

       $(document).ready(function() {
       
           function hidetab(){    
            $('#mssg').hide();
          }
            setTimeout(hidetab,4000);
       });
    </script>

</body>


</html>