<?php include 'modal.php';?>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>


<div class="header">
        <div class="pull-left">
            <div class="logo"><a href="<?php echo base_url();?>Adminity"><img src="<?php echo base_url();?>mypanel/assets/img/logo.png" alt="Tirupati Travels" /></a></div>
            <div class="hamburger sidebar-toggle">
                <span class="line"></span>
                <span class="line"></span>
                <span class="line"></span>
            </div>
        </div>
        <div class="pull-right p-r-15">
            <ul>

                <li class="header-icon dib">
                    <img class="avatar-img" src="<?php echo base_url();?>assets/uploads/supervisors/<?php echo $this->session->userdata('log_image');?>" alt="" /> 
                    <span class="user-avatar"><?php echo $this->session->userdata('log_admin_name');?> <i class="ti-angle-down f-s-10"></i></span>
                    <div class="drop-down dropdown-profile">                        
                        <div class="dropdown-content-body">
                            <ul>
                                <li><a href="<?php echo base_url();?>Supervisor/profile"><i class="ti-user"></i> <span>Profile</span></a></li>
                                <li><a href="<?php echo base_url();?>Supervisor/profile"><i class="ti-settings"></i> <span>Setting</span></a></li>
                                <li><a href="<?php echo base_url();?>Supervisor/logout"><i class="ti-power-off"></i> <span>Logout</span></a></li>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>