<?php  
$vendor=$this->db->get('tbl_vendor')->result_array(); 
 $assign = $this->admin->getAllAssignVehicleDriver();
?>
<style>
    .modal-dialog{
    width: 50%;
    }
</style>
<!-- Styles -->

  <section id="main-content">
        
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card alert">
                                <div class="card-body">
                                    <div class="card-header m-b-20">
                                        <h4>Assign Vehicle to Fuel</h4>                                        
                                    </div>
                                </div>
                                <form action="<?php echo base_url();?>Supervisor/assignVehicleToFuel" method="post">   
                                <div class="row">

                                   
                                     <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                <label>Select Vehicle <span class="required">*</span></label>
                                                <select class="form-control etype" required="" name="assign_id" id="assign_id">
                                                    <option value=""> ---Select Vehicle--- </option>
                                                    <?php
                                                    foreach($assign as $row)
                                                    {?>
                                                     <option value="<?php echo $row['assign_id'];?>"><?php echo $row['vehicle_no'];?></option>
                                                    <?php }
                                                    ?>
                                                </select> 
                                               
                                            </div>
                                        </div>
                                    </div>
                                    
                                     <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                <label>Select Fuel Pump <span class="required">*</span></label>
                                                <select class="form-control etype" required="" name="vendor_id" id="vendor_id">
                                                    <option value=""> ---Select Fuel Pump--- </option>
                                                    <?php
                                                    foreach($vendor as $ven)
                                                    {?>
                                                     <option value="<?php echo $ven['vendor_id'];?>"><?php echo $ven['vendor_name'];?></option>
                                                    <?php }
                                                    ?>
                                                </select> 
                                               
                                            </div>
                                        </div>
                                    </div>  
                                
                                    <div class="col-md-12">
                                        <div class="basic-form">
                                            <div class="form-group">
                                                <label>Fuel Amount (<i class="fa fa-inr"></i>)<span class="required">*</span></label>
                                                <input type="text" name="cost" required="" maxlength="10"  pattern="[0-9]+([\.][0-9]{0,4})?" class="form-control border-none input-flat bg-ash" placeholder="Fuel Amount">
                                            </div>
                                        </div>
                                    </div>
                                         
                                    
                                                                       
                                    <div class="col-md-12">
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-info btn-lg  border-none sbmt-btn"><i class="ti-save"></i> Assign</button>
                                            <button type="button" class="btn btn-primary btn-lg border-none sbmt-btn" data-dismiss="modal"><i class="ti-close"></i> Close</button>
                                        </div>  
                                   </div>
                                </div>                                
                                </form>
                            </div>
                        </div>
                    </div>
                  
                    
         
                    
   </section>

    <!-- scripit init-->

<!--
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/moment.latest.min.js"></script>
     scripit init
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/semantic.ui.min.js"></script>
     scripit init
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/prism.min.js"></script>
     scripit init
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/pignose.calendar.min.js"></script>
     scripit init
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/pignose.init.js"></script>
     scripit init-->
