<?php include 'header-top.php';?>
<style>
    .highcharts-credits{
        display: none;
    }
</style>
<body>

    <!-- # sidebar -->
    <?php include 'sidebar.php';?>
    <!-- /# sidebar -->


    <!-- # header -->
    <?php include 'header.php';?>
    <!-- /# header -->
    
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
             
                <!---page title-->
                <?php include 'page-title.php';?>

                  
                <!---/page-title--->
                               
                <section id="main-content">
                    <div class="row">                       
                      
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="stat-widget-eight">
                                    <div class="stat-header">
                                        <div class="header-title pull-left">Total Fuel Pumps</div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="stat-content">
                                        <div class="pull-left">
                                            <i style="font-size:40px" class="ti-layout-tab-v color-danger"></i>
                                            <span class="stat-digit">
                                                <?php  $this->db->from('tbl_vendor');
                                                      echo $this->db->count_all_results(); ?>
                                               </span>
                                        </div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="stat-widget-eight">
                                    <div class="stat-header">
                                        <div class="header-title pull-left">Total Drivers</div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="stat-content">
                                        <div class="pull-left">
                                            <i style="font-size:40px" class="ti-wheelchair color-danger"></i>
                                            <span class="stat-digit"> 
                                                <?php  $this->db->from('tbl_driver');
                                                      echo $this->db->count_all_results(); ?>
                                            </span>
                                        </div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="stat-widget-eight">
                                    <div class="stat-header">
                                        <div class="header-title pull-left">Total Vehicles</div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="stat-content">
                                        <div class="pull-left">
                                            <i style="font-size:40px" class="ti-truck color-danger"></i>
                                            <span class="stat-digit"> 
                                                <?php  $this->db->from('tbl_vehicle');
                                                      echo $this->db->count_all_results(); ?>
                                            </span>
                                        </div>
                                       
                                    </div>
                                    <div class="clearfix"></div>
                                    
                                </div>
                            </div>
                        </div>
                     
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="stat-widget-eight">
                                    <div class="stat-header">
                                        <div class="header-title pull-left">Assigned Driver to Vehicle</div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="stat-content">
                                        <div class="pull-left">
                                            <i style="font-size:40px" class="ti-direction-alt color-danger"></i>
                                            <span class="stat-digit"> 
                                                <?php  
                                                        $this->db->from('tbl_assign');
                                                      echo $this->db->count_all_results(); ?>
                                            </span>

                                        </div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="stat-widget-eight">
                                    <div class="stat-header">
                                        <div class="header-title pull-left">Assigned Vehicle for Fuel</div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="stat-content">
                                        <div class="pull-left">
                                             <i style="font-size:40px" class="ti-truck color-danger"></i>
                                            <span class="stat-digit"> 
                                                <?php $this->db->where('supervisor_id',$this->session->userdata('log_admin_id'));
                                                $this->db->where('status',0);
                                                $this->db->from('fuel_mgt');
                                               echo $this->db->count_all_results(); ?>
                                            </span>
                                        </div>
                                       
                                    </div>
                                    <div class="clearfix"></div>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="stat-widget-eight">
                                    <div class="stat-header">
                                        <div class="header-title pull-left">My Fuel Receipts</div>
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="stat-content">
                                        <div class="pull-left">
                                            <i style="font-size:40px" class="ti-receipt color-danger"></i>
                                            <span class="stat-digit"> 
                                                <?php //$this->db->where('status',0);
                                                $this->db->where('supervisor_id',$this->session->userdata('log_admin_id'));
                                                $this->db->from('fuel_receipt');
                                                      echo $this->db->count_all_results(); ?>
                                            </span>
                                        </div>
                                       
                                    </div>
                                    <div class="clearfix"></div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                  
                    
                 
                  
                    <!-- /# row -->
                    <!--FOOTER CONTENTS--->
                     <?php include 'footer-contents.php';?>
                    <!---/FOOTER CONTENTS-->
                </section>
            </div>
        </div>
    </div>

  

<script>
Highcharts.chart('containerr', {
    chart: {
        type: 'column'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: 'Todays Sale By Vendor.'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'Todays  Fuel Cost'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: 'Rs.{point.y:.1f}'
            }
        }
    },

    tooltip: {
        pointFormat: '<span style="color:{point.color}">Todays Sale of {point.name} Rs:</span><b>{point.y:.2f}</b><br/>'
    },

    series: [{
        name: 'Vendor',
        colorByPoint: true,
        data:  [ <?php echo $maainseries;?> ]
        
    }],
    
});
</script>

<script>
Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'vendor Report'
    },
    subtitle: {
        text: '.'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'Total percent market share'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.1f}'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}</b> of total<br/>'
    },

    series: [{
        name: 'Month',
        colorByPoint: true,
        data: [{
            name: 'January',
            y: <?php echo $jan; ?>,
            drilldown: 'January'
        }, {
            name: 'February',
            y: <?php echo $feb; ?>,
            drilldown: 'February'
        }, {
            name: 'March',
            y: <?php echo $mar; ?>,
            drilldown: 'March'
        }, {
            name: 'April',
            y: <?php echo $apr; ?>,
            drilldown: 'April'
        }, {
            name: 'May',
            y: <?php echo $may; ?>,
            drilldown: 'May'
        }, {
            name: 'June',
            y:<?php echo $jun; ?>,
            drilldown: 'June'
        },{
            name: 'July',
            y: <?php echo $jul; ?>,
            drilldown: 'July'
        },{
            name: 'August',
            y: <?php echo $aug; ?>,
            drilldown: 'August'
        },
        {
            name: 'September',
            y: <?php echo $sep; ?>,
            drilldown: 'September'
        },
         {
            name: 'October',
            y: <?php echo $oct; ?>,
            drilldown: 'October'
        },
         {
            name: 'November',
            y: <?php echo $nov; ?>,
            drilldown: 'November'
        },
         {
            name: 'December',
            y: <?php echo $dec; ?>,
            drilldown: 'December'
        }]
    }],
    drilldown: {
        series: [<?php echo $maain;?>]
    }
});


 
</script>

     <!-- # footer -->
    <?php include 'footer.php';?>
    <!-- /# footer -->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/chart-js/Chart.bundle.js"></script>
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/chart-js/chartjs-init.js"></script>


     <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/moment.latest.min.js"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/semantic.ui.min.js"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/prism.min.js"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/pignose.calendar.min.js"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url();?>mypanel/assets/js/lib/calendar-2/pignose.init.js"></script>

</body>


</html>