<div class="row">
    <div class="col-lg-12">
        <div class="footer">
            <p style="color:#878787">&copy; Developed By <a style="color: #e74c3c" href="http://www.rnltechnologies.com/" target="_blank"  class="page-refresh">RNL Technologies Pvt. Ltd.</a></p>
        </div>
    </div>
</div>