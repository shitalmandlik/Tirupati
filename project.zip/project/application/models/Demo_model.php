<?php
class Demo_model extends CI_Model
{
  public function upload_file($data)
  {
   //return $this->db->get('category_tbl')->result_array();
    
    $this->db->insert('vehicaldetails_tbl',$data);
  }
   
}

?>