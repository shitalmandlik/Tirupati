<?php
  function notificationCount()
  {
        $ci=& get_instance();
        $ci->load->database(); 

     $data=$ci->db->query("select * from vehicaldetails_tbl t1 join document_tbl t2 on t1.vehical_id=t2.vehical_id join category_tbl t3 on t2.category_id=t3.category_id where status='0'")->result_array();
 $cnt=0;
					foreach ($data as $value)
                             {
                                           
                                                $date=$value['expiry_date'];
                                                $date=date_create($date);
                                                $today=date_create();
                                                $diff   = date_diff($today,$date );
                                                $diff1=$diff->format("%R%a");
                                                if($diff1<30)
                                                    { 
                                                          $value['owner_name'];
                                                          $value['register_number']; 
                                                          $value['category_name'];
                                                          $value['expiry_date']; 
                                                        

                                                     $cnt++; 
                                               	 }  
                    
                           }
                        
                        return $cnt;

   }
?>