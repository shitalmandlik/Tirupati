 function searchData(){

        $search = $("#search-data").val();
     	
        if($search !=''/* && $select==2*/){
        $('.result').addClass('disp');
         $('.result').html("<li class='search-product'><img width='25' src='<?php echo base_url(); ?>mypanel/assets/img/loading.gif'></img></li>");
       $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>Adminity/vehicalData",
            data: { search: $search },
            dataType: "json",
            success: function (data) { 
                if (data.length > 0) {                   
                  $('.result').empty();                  
                     $.each(data, function (key,value) {
                         var number= value['register_number'];
                            var id= value['vehicle_id'];
                            /*var ref_no= value['product_code'];
                            var prod_url= value['product_url']; */                       
                         $('.result').append('<a href="<?php echo base_url();?>Adminity/vehicalData/"><li class="search-product">' + number + '</li></a>');
                     });
                     //$search = $("#search-data").val(name);
                }
                else{
                     $('.result').html('<li class="search-product"> No Record Found..!</li>');                      
                }
            } 
            });
}
}





